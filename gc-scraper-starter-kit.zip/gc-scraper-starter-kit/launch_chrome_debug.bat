@echo off
REM ---------------------------------------------------------------------------
REM launch_chrome_debug.bat — start Chrome with the DevTools debug port open,
REM using a DEDICATED profile so it never touches your normal Chrome/browsing.
REM
REM gc_harvest.py connects to this Chrome (port 9222) and reads the live
REM gc-token off web.gc.com's own requests. Steps:
REM   1. Double-click this file.
REM   2. In the Chrome window that opens, go to https://web.gc.com and log in.
REM   3. Leave it open. Run:  python gc_harvest.py
REM      (writes to tokens.txt in this same scraper.v9 folder by default --
REM      that's what gc_scraper.py and gc_client.py read from. Only pass
REM      --out if you deliberately want it somewhere else. Note:
REM      fetch_handedness.py does NOT use tokens.txt at all -- it drives
REM      this Chrome window's own logged-in session directly via Selenium.)
REM
REM The dedicated profile means you log in once here; it stays logged in and
REM auto-refreshes its token every ~55 min, so future harvests need no re-login.
REM ---------------------------------------------------------------------------

set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" (
  echo Could not find chrome.exe in the usual locations.
  echo Edit this file and set CHROME to your chrome.exe path.
  pause
  exit /b 1
)

set "PROFILE=%LOCALAPPDATA%\gc-harvest-chrome"

echo Launching Chrome with remote debugging on port 9222...
echo Profile: %PROFILE%
echo.
echo Log in to https://web.gc.com in the window that opens, then leave it running.
echo.

REM --remote-allow-origins is REQUIRED on Chrome 111+: without it Chrome rejects
REM the DevTools websocket with "403 Forbidden ... Use --remote-allow-origins".
REM Scoped to the loopback debug origin the harvester connects from; safe on a
REM dedicated local profile.
start "" "%CHROME%" --remote-debugging-port=9222 --remote-allow-origins=http://127.0.0.1:9222 --user-data-dir="%PROFILE%" https://web.gc.com
