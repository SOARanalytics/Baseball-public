r"""
gc_harvest.py — read the live gc-token from a running Chrome and write tokens.txt.

Why this exists
---------------
GameChanger's /auth endpoint is protected by a request signature (gc-signature)
computed with a secret inside their minified JS, so tokens CANNOT be minted or
refreshed from Python (see the project memory / gc_client.py header). The token
in localStorage is AES-encrypted with a key that is also derived in JS, so
reading it off disk yields ciphertext.

But the browser, running GameChanger's real signed JS, refreshes its own token
every ~55 minutes and works perfectly. And every ordinary data request it makes
carries the token as a PLAINTEXT `gc-token` request header, unsigned — the data
endpoints don't require the signature, only /auth does.

So instead of reproducing GC's auth (adversarial, fragile, against their intent)
this harvests the token the browser already holds. It reads your own browser's
normal outbound traffic via the Chrome DevTools Protocol. Nothing is decrypted,
nothing is forged.

  browser (signed JS, auto-refreshes)  →  gc-token header on every request
                                        →  gc_harvest.py lifts it
                                        →  tokens.txt
                                        →  gc_scraper.py / the MCP use it

Prerequisite: Chrome must be running with remote debugging enabled and you must
be logged in to web.gc.com in it. Use launch_chrome_debug.bat (generated
alongside this file), which points a DEDICATED Chrome profile at port 9222 so it
never touches your normal browsing.

Usage
-----
    python gc_harvest.py                       # harvest once, write tokens.txt, exit
    python gc_harvest.py --out path/tokens.txt # choose the output file
    python gc_harvest.py --watch               # stay running, refresh the file
                                               #   whenever a newer token appears
    python gc_harvest.py --no-reload           # don't reload the tab to force a request

    # Repeat --out for several destinations. Both consumers need the token:
    # the NAS container (mounted share) and the local gc_scraper.py, which must
    # keep working standalone without the MCP server.
    python gc_harvest.py --watch \
        --out X:\gc-mcp\data\tokens.txt \
        --out C:\ClaudeProject\working\Soar\scraper.v8\tokens.txt

One destination failing (offline share, bad path) does not stop the others —
the failure is reported and the remaining writes still happen.

Exit codes: 0 harvested, 2 no Chrome on the port, 3 no gc.com tab, 4 timed out.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path
from urllib.request import urlopen

try:
    import websocket  # websocket-client
except ImportError:
    sys.exit(
        "Missing dependency: pip install websocket-client\n"
        "(this is the Chrome DevTools Protocol transport)"
    )

# Where the debug Chrome is. Defaults to this machine. Override when the
# browser lives on a different host than the harvester — e.g. harvesting from
# a container to a Chrome on your PC (see NAS_DEPLOYMENT.md, and read the
# security warning there first: exposing Chrome's debug port on a LAN lets
# anyone on that LAN drive your logged-in browser).
DEBUG_HOST = os.environ.get("GC_DEBUG_HOST", "127.0.0.1")
DEBUG_PORT = int(os.environ.get("GC_DEBUG_PORT", "9222"))
API_HOST = "api.team-manager.gc.com"
GC_TAB_MATCH = "gc.com"
DEFAULT_TIMEOUT = 30


# ---------------------------------------------------------------------------
# Token decoding (duplicated minimally rather than importing, so the harvester
# stands alone even if gc_client.py moves)
# ---------------------------------------------------------------------------


def _decode_jwt(token: str) -> dict:
    try:
        part = token.split(".")[1]
        part += "=" * (-len(part) % 4)
        return json.loads(base64.urlsafe_b64decode(part))
    except Exception:
        return {}


def _describe(token: str) -> str:
    c = _decode_jwt(token)
    exp = c.get("exp")
    if not exp:
        return "token: no exp"
    mins = (exp - time.time()) / 60
    return f"token: type={c.get('type')} expires in {mins:.0f} min"


# ---------------------------------------------------------------------------
# Chrome DevTools Protocol — just enough of it, no framework
# ---------------------------------------------------------------------------


class CDP:
    """A tiny synchronous CDP client over one tab's websocket."""

    def __init__(self, ws_url: str) -> None:
        self._ws = websocket.create_connection(ws_url, max_size=None)
        self._id = 0

    def send(self, method: str, params: dict | None = None) -> int:
        self._id += 1
        self._ws.send(json.dumps({"id": self._id, "method": method, "params": params or {}}))
        return self._id

    def recv(self, timeout: float | None = None) -> dict:
        if timeout is not None:
            self._ws.settimeout(timeout)
        return json.loads(self._ws.recv())

    def close(self) -> None:
        try:
            self._ws.close()
        except Exception:
            pass


def list_tabs() -> list[dict]:
    url = f"http://{DEBUG_HOST}:{DEBUG_PORT}/json"
    with urlopen(url, timeout=5) as r:
        return json.loads(r.read())


def find_gc_tab(tabs: list[dict]) -> dict | None:
    for t in tabs:
        if t.get("type") == "page" and GC_TAB_MATCH in (t.get("url") or ""):
            return t
    return None


# ---------------------------------------------------------------------------
# Harvest
# ---------------------------------------------------------------------------


def harvest_once(
    out_paths: Path | list[Path],
    timeout: float = DEFAULT_TIMEOUT,
    reload_tab: bool = True,
) -> dict | None:
    """Capture one gc-token from a live request and write it to every destination.

    `out_paths` takes a single Path or a list of them. A single Path is still
    accepted so existing callers (gc_scraper.py's refresh hook, the MCP
    server's) keep working unchanged.

    Returns token info incl. a `written` list on success, None on timeout.
    """
    if isinstance(out_paths, (str, Path)):
        out_paths = [Path(out_paths)]
    out_paths = [Path(p) for p in out_paths]
    try:
        tabs = list_tabs()
    except OSError:
        print(f"No Chrome debug endpoint on {DEBUG_HOST}:{DEBUG_PORT}.")
        print("Launch Chrome with launch_chrome_debug.bat first, and log in to web.gc.com.")
        sys.exit(2)

    tab = find_gc_tab(tabs)
    if not tab:
        print("Chrome is running with debugging, but no web.gc.com tab is open.")
        print("Open https://web.gc.com and log in, then rerun.")
        sys.exit(3)

    cdp = CDP(tab["webSocketDebuggerUrl"])
    try:
        cdp.send("Network.enable")
        if reload_tab:
            # An idle tab may not make a request for a while. A reload makes the
            # app immediately re-fetch /me/* etc., each carrying gc-token.
            cdp.send("Page.enable")
            cdp.send("Page.reload", {"ignoreCache": False})

        deadline = time.time() + timeout
        best_token = ""
        device_id = ""
        while time.time() < deadline:
            try:
                msg = cdp.recv(timeout=max(0.5, deadline - time.time()))
            except websocket.WebSocketTimeoutException:
                break
            if msg.get("method") != "Network.requestWillBeSent":
                continue
            req = msg["params"]["request"]
            if API_HOST not in req.get("url", ""):
                continue
            # Header names arrive with original casing; match case-insensitively.
            headers = {k.lower(): v for k, v in req.get("headers", {}).items()}
            token = headers.get("gc-token", "")
            if not token:
                continue
            claims = _decode_jwt(token)
            if claims.get("type") != "user":
                continue  # skip client tokens; we want the user token
            best_token = token
            device_id = headers.get("gc-device-id", device_id)
            break

        if not best_token:
            return None

        written = _write_tokens(out_paths, best_token, device_id)
        if not written:
            raise OSError(
                "Harvested a token but could not write it to any destination: "
                + ", ".join(str(p) for p in out_paths)
            )
        return {
            "token": best_token,
            "device_id": device_id,
            "claims": _decode_jwt(best_token),
            "written": written,
        }
    finally:
        cdp.close()


def _write_tokens(out_paths: list[Path], token: str, device_id: str) -> list[Path]:
    """Write the token to every destination. Returns the paths actually written.

    Multiple destinations exist because two independent consumers need the same
    credential: the NAS container (via a mounted share) and the local
    gc_scraper.py, which must keep working standalone without the MCP server.
    Writing only one leaves the other silently stale.

    A failure on one destination does NOT abort the others — a disconnected
    network drive must not stop the local copy being refreshed. Failures are
    reported to stderr and reflected in the returned list.

    Note: the harvested request header is the ACCESS token only — the browser
    keeps the 14-day refresh token encrypted and never puts it on the wire, so
    tokens.txt gets no gc-refresh-token line from here. That is fine: this file
    is refreshed straight from the browser whenever it goes stale, so the
    Python-side refresh path is never needed.
    """
    lines = [f"gc-token: {token}"]
    if device_id:
        lines.append(f"gc-device-id: {device_id}")
    body = "\n".join(lines) + "\n"

    written: list[Path] = []
    for p in out_paths:
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(body, encoding="utf-8")
            written.append(p)
        except OSError as exc:
            print(f"  ! could not write {p}: {exc}", file=sys.stderr)
    return written


def _current_token(out_path: Path) -> str:
    if not out_path.exists():
        return ""
    for line in out_path.read_text(encoding="utf-8").splitlines():
        if line.lower().startswith("gc-token:"):
            return line.split(":", 1)[1].strip()
    return ""


def watch(out_paths: list[Path], interval: float = 300.0) -> None:
    """Keep every tokens.txt fresh: harvest whenever the browser has a newer token.

    Polls every `interval` seconds. Cheap — one reload + a few CDP messages.
    Meant to run in the background beside a long scrape or dev session.

    "Changed" is judged against the FIRST destination only; all destinations are
    written every cycle regardless, so a share that was offline earlier gets
    caught up on the next pass rather than staying stale until the token
    happens to change.
    """
    print("Watching — refreshing every %.0fs. Ctrl+C to stop." % interval)
    for p in out_paths:
        print(f"    → {p}")
    while True:
        try:
            prev = _current_token(out_paths[0])
            info = harvest_once(out_paths, reload_tab=True)
            stamp = time.strftime("%H:%M:%S")
            if info:
                state = "updated" if info["token"] != prev else "unchanged"
                n_ok = len(info.get("written", []))
                partial = "" if n_ok == len(out_paths) else f"  [{n_ok}/{len(out_paths)} written]"
                print(f"  {stamp}  {state} — {_describe(info['token'])}{partial}")
            else:
                print(f"  {stamp}  no token seen this cycle")
        except SystemExit:
            raise
        except Exception as exc:
            print(f"  {time.strftime('%H:%M:%S')}  error: {exc}")
        time.sleep(interval)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Harvest gc-token from a running Chrome.",
        epilog="Repeat --out to write the same token to several places, e.g. the "
        "NAS share AND the local folder gc_scraper.py reads from.",
    )
    ap.add_argument(
        "--out",
        action="append",
        metavar="PATH",
        help="output file; repeat for multiple destinations (default tokens.txt)",
    )
    ap.add_argument("--watch", action="store_true", help="run continuously")
    ap.add_argument("--interval", type=float, default=300.0, help="--watch poll seconds")
    ap.add_argument("--no-reload", action="store_true", help="don't reload the tab")
    ap.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    args = ap.parse_args()

    # argparse's append leaves None when the flag is absent — don't let a
    # default in the add_argument call get prepended to user-supplied values.
    out_paths = [Path(p) for p in (args.out or ["tokens.txt"])]

    if args.watch:
        watch(out_paths, interval=args.interval)
        return

    info = harvest_once(out_paths, timeout=args.timeout, reload_tab=not args.no_reload)
    if not info:
        print(f"No gc-token seen within {args.timeout:.0f}s.")
        print("Is the web.gc.com tab logged in? Try without --no-reload.")
        sys.exit(4)

    print("Harvested →")
    for p in info["written"]:
        print(f"    {p}")
    missing = [p for p in out_paths if p not in info["written"]]
    for p in missing:
        print(f"    FAILED: {p}")
    print(f"  {_describe(info['token'])}")
    print(f"  device_id: {info['device_id'] or '(not seen)'}")
    if missing:
        sys.exit(5)


if __name__ == "__main__":
    main()
