#!/usr/bin/env python3
r"""
handedness_overrides.py — re-apply coach-supplied handedness after a scrape

Why this exists
----------------
GameChanger has no handedness on file for ~22% of players league-wide, and
for some teams (BCC Big Train among them) it's missing for most of the
roster. That gap is in GC's own data, not our scrape — verified against the
manager-scoped endpoint, which returns the same blanks. No amount of
rescraping fixes it.

So for teams where a human actually knows the answers, a coach-maintained
file is the source of truth. The problem: gc_scraper.py rewrites
_handedness.yaml from GC on every scrape, which silently reverts those
values to NA. With frequent rescrapes coming next season, a manual
re-apply is guaranteed to be forgotten exactly once and then quietly
corrupt a season of spray analysis.

This module makes the override survive a rescrape. gc_scraper.py calls
apply_overrides_to_snapshot() right after writing _handedness.yaml, so the
coach values are reasserted as part of the normal scrape.

Override file format
---------------------
Any file matching *_roster_handedness.yaml or *_handedness.yaml in this
folder or in handedness_overrides/, containing a team_slug header:

    # team_slug: bcc-big-train-11u
    roster_handedness:
      Beckett Dickinson:
        bat: L
        throw: L

The team_slug header is what binds the file to a team; it's matched against
the raw/ directory name, so one file covers every season of that team.
Without the header the file is skipped with a warning rather than guessed
at — a wrong team binding would be worse than no override.

It accepts glob patterns and a comma-separated list:

    # team_slug: bcc-big-train-*

That matters because teams AGE UP. BCC was bcc-big-train-11u through spring
2026 and became bcc-big-train-12u in fall 2026 — 11 of 13 players carried
over, but a literal 11u binding silently stopped applying and six of them
lost their handedness again. A glob follows the team into 13u without
anyone remembering to edit this file.

Merge semantics (deliberately not a blind overwrite)
-----------------------------------------------------
Only bat/throw are taken from the override. Specifically preserved:
  - the GC player uuid comment, which is the only reliable join key (GC
    renders most rosters as "Alex D", so names collide across teams)
  - roster entries absent from the override file, e.g. the "Guest 1" /
    "Guest 2" placeholders that show up in box scores
A straight file copy would lose both.

Conflicts (GC has a value AND the override disagrees) are reported rather
than silently resolved. When BCC was first applied on 2026-08-14 there were
zero conflicts across 24 rows, which is a reasonable signal the coach file
is trustworthy — if that ever stops being true, it should be visible.

Usage:
    python handedness_overrides.py            # sweep all of raw/, report
    python handedness_overrides.py --dry-run  # show what would change
"""

from __future__ import annotations

import argparse
import datetime
import fnmatch
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
OVERRIDE_DIRS = [SCRIPT_DIR, SCRIPT_DIR / "handedness_overrides"]
OVERRIDE_GLOBS = ["*_roster_handedness.yaml", "*_handedness.yaml"]

TEAM_SLUG_RE = re.compile(r"^#\s*team_slug:\s*(\S+)", re.MULTILINE)
ENTRY_RE = re.compile(
    r"^  (?P<name>[^\n:]+):(?P<comment>[^\n]*)\n"
    r"\s+bat:\s*(?P<bat>\S+)\n"
    r"\s+throw:\s*(?P<throw>\S+)",
    re.MULTILINE,
)
UUID_RE = re.compile(r"person_id:\s*([0-9a-fA-F-]{36})")


def parse_entries(text: str) -> dict[str, tuple[str, str]]:
    """name -> (bat, throw). Works on both override files and raw files."""
    return {
        m.group("name").strip(): (m.group("bat").strip(), m.group("throw").strip())
        for m in ENTRY_RE.finditer(text)
    }


def load_overrides(dirs=None) -> dict[str, dict]:
    """Discover override files and index them by team_slug."""
    out: dict[str, dict] = {}
    seen: set[Path] = set()
    for d in (dirs or OVERRIDE_DIRS):
        if not Path(d).is_dir():
            continue
        for pattern in OVERRIDE_GLOBS:
            for path in sorted(Path(d).glob(pattern)):
                if path in seen or path.parent.name == "gamechanger":
                    continue
                seen.add(path)
                text = path.read_text(encoding="utf-8")
                if "roster_handedness:" not in text:
                    continue
                m = TEAM_SLUG_RE.search(text)
                if not m:
                    print(f"  ⚠️  {path.name}: no '# team_slug:' header — skipped "
                          f"(add one to bind it to a team)")
                    continue
                entries = parse_entries(text)
                if entries:
                    patterns = [p.strip() for p in m.group(1).split(",") if p.strip()]
                    for pat in patterns:
                        out[pat] = {"path": path, "entries": entries}
    return out


def match_team(team_slug: str, overrides: dict) -> dict | None:
    """Find the override whose team_slug pattern matches this team.

    Exact match wins over a glob, so a team-specific file can override a
    club-wide one. Globs exist because teams age up (…-11u -> …-12u) and a
    literal binding silently stops applying the season that happens.
    """
    if team_slug in overrides:
        return overrides[team_slug]
    for pattern, entry in overrides.items():
        if fnmatch.fnmatch(team_slug, pattern):
            return entry
    return None


def apply_override(current_text: str, entries: dict[str, tuple[str, str]],
                   source_name: str) -> tuple[str, dict]:
    """Merge override values into an existing _handedness.yaml.

    Returns (new_text, stats). Preserves uuids and non-override entries.
    """
    today = datetime.date.today().isoformat()
    rows, conflicts, changed, kept = [], [], 0, []

    for m in ENTRY_RE.finditer(current_text):
        name = m.group("name").strip()
        um = UUID_RE.search(m.group("comment"))
        uuid = um.group(1) if um else ""
        bat, throw = m.group("bat").strip(), m.group("throw").strip()
        from_coach = False
        if name in entries:
            nb, nt = entries[name]
            if bat != "NA" and (bat, throw) != (nb, nt):
                conflicts.append((name, (bat, throw), (nb, nt)))
            if (bat, throw) != (nb, nt):
                changed += 1
            bat, throw = nb, nt
            from_coach = True
        else:
            kept.append(name)
        rows.append((name, uuid, bat, throw, from_coach))

    header = (
        f"# Handedness — overridden from {source_name} on {today}.\n"
        f"# Coach-supplied values are authoritative here: GameChanger has no\n"
        f"# handedness on file for much of this roster, so no rescrape will fill it.\n"
        f"# Only bat/throw come from the override; GC player uuids and any roster\n"
        f"# entries absent from the override file are preserved as scraped.\n"
        f"# Re-applied automatically by handedness_overrides.py after every scrape.\n\n"
    )
    body = ["roster_handedness:\n\n"]
    for name, uuid, bat, throw, from_coach in sorted(rows, key=lambda r: r[0]):
        parts = []
        if uuid:
            parts.append(f"person_id: {uuid}")
        if bat == "NA" and throw == "NA":
            parts.append("TODO — not in GC")
        elif from_coach:
            parts.append("source: coach file")
        comment = f"   # {'; '.join(parts)}" if parts else ""
        body.append(f"  {name}:{comment}\n    bat: {bat}\n    throw: {throw}\n\n")

    stats = {
        "players": len(rows),
        "with_handedness": sum(1 for r in rows if r[2] != "NA"),
        "changed": changed,
        "conflicts": conflicts,
        "kept_as_scraped": kept,
    }
    return header + "".join(body), stats


def apply_overrides_to_snapshot(out_dir: Path, team_slug: str,
                                overrides: dict | None = None,
                                verbose: bool = True) -> dict | None:
    """Re-apply any override for `team_slug` to out_dir/_handedness.yaml.

    Called by gc_scraper.py immediately after it writes that file. Returns
    None when no override exists for the team (the common case). Never
    raises — an override problem must not fail a scrape that worked.
    """
    try:
        overrides = load_overrides() if overrides is None else overrides
        entry = match_team(team_slug, overrides)
        if not entry:
            return None
        path = out_dir / "_handedness.yaml"
        if not path.exists():
            return None
        new_text, stats = apply_override(
            path.read_text(encoding="utf-8"), entry["entries"], entry["path"].name
        )
        path.write_text(new_text, encoding="utf-8")
        if verbose:
            print(f"  Handedness override applied from {entry['path'].name}: "
                  f"{stats['with_handedness']}/{stats['players']} with handedness "
                  f"({stats['changed']} changed)")
            for name, was, now in stats["conflicts"]:
                print(f"    ⚠️  conflict {name}: GC={was} coach={now} (coach wins)")
        return stats
    except Exception as exc:  # never break a scrape over this
        if verbose:
            print(f"  ⚠️  Could not apply handedness override: {exc!r}")
        return None


# ---------------------------------------------------------------------------
# CLI — sweep every snapshot in raw/
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root", type=Path,
                    default=SCRIPT_DIR / "raw" / "gamechanger")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    overrides = load_overrides()
    if not overrides:
        sys.exit("No override files found. Expected a *_roster_handedness.yaml "
                 f"with a '# team_slug:' header in {SCRIPT_DIR} or "
                 f"{SCRIPT_DIR / 'handedness_overrides'}.")

    print(f"Override files ({len(overrides)}):")
    for slug, e in overrides.items():
        print(f"  {slug:32} <- {e['path'].name} ({len(e['entries'])} players)")

    total = 0
    seen_paths: set = set()
    for path in sorted(args.raw_root.glob("*/*/*/_handedness.yaml")):
        slug = path.parts[-3]
        entry = match_team(slug, overrides)
        if entry is None or path in seen_paths:
            continue
        seen_paths.add(path)
        if True:
            season = path.parts[-4]
            new_text, stats = apply_override(
                path.read_text(encoding="utf-8"), entry["entries"], entry["path"].name
            )
            action = "would write" if args.dry_run else "wrote"
            if not args.dry_run:
                path.write_text(new_text, encoding="utf-8")
            print(f"\n{slug} / {season}: {action} "
                  f"{stats['with_handedness']}/{stats['players']} with handedness, "
                  f"{stats['changed']} changed")
            if stats["kept_as_scraped"]:
                print(f"  kept as scraped (not in override): {stats['kept_as_scraped']}")
            if stats["conflicts"]:
                for name, was, now in stats["conflicts"]:
                    print(f"  ⚠️  conflict {name}: GC={was} coach={now} (coach wins)")
            else:
                print("  no conflicts with scraped values")
            total += 1
    print(f"\n{total} snapshot(s) processed.")
    if not args.dry_run and total:
        print("Re-run warehouse/build_bronze.py to load the change.")


if __name__ == "__main__":
    main()
