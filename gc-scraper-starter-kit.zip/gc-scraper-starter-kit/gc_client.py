"""
gc_client.py — reusable GameChanger API core.

Extracted from gc_scraper.py v7. This module owns ONE thing that v7 did badly:
credential lifetime. It does not scrape schedules, does not parse boxscores,
does not write files. Selenium stays in the scraper.

The problem it solves
---------------------
The gc-token is a JWT with a ~65 minute lifetime. Any batch scrape longer than
an hour hits expiry mid-run, which is why v7 had an interactive paste prompt.

Auth flow (captured from web.gc.com, confirmed)
-----------------------------------------------
All stages POST to the SAME url, https://api.team-manager.gc.com/auth,
discriminated by a `type` field:

  1. {"type": "client-auth", "client_id": CLIENT_ID}
        -> {"type": "client-token", "token": <jwt>, "expires": <epoch>}
           10 minute lifetime. Claims: type=client, sid, cid.

  2. {"type": "user-auth", "email": EMAIL}      (bearer: client token)
        -> challenge / accepted-methods

  3. {"type": "password", "password": PASSWORD}  (bearer: client token)
        -> {"type": "token",
            "access":  {"data": <jwt>, "expires": <epoch>},
            "refresh": {"data": <jwt>, "expires": <epoch>},
            "user_id": <uuid>}

Stages 2 and 3 carry NO reference to stage 1 or to each other in the body.
The server correlates them through the `sid` claim inside the client token,
so the client token MUST be sent as the gc-token header on stages 2 and 3.
Miss that and stage 2 fails in a way that looks like a bad email.

THE KEY CORRECTION: stage 3 does not return one token, it returns two, in a
nested access/refresh envelope. This was missed for a while — a flat
{"token": ...} parser silently found nothing in this shape and every prior
"successful" login was actually a different bug (see git history / worklog).

  access.data  — the JWT used as gc-token on every API call. ~65 min.
                 Carries a `rtkn` claim, which is NOT itself a bearer — it's
                 a correlator equal to the `id` claim inside refresh.data.
  refresh.data — a SEPARATE JWT, signed with a different key (different
                 `kid`), lifetime 14.0 days exactly. THIS is the actual
                 refresh credential.

  4. {"type": "refresh"}  + gc-token header = refresh.data (NOT access.data)
        -> same {"type": "token", access: {...}, refresh: {...}} envelope.
           Best current hypothesis for where the refresh JWT goes: the
           gc-token header, in place of the (possibly expired) access token,
           since gc-token is the one header every other authenticated call
           uses. NOT YET CONFIRMED — sending access.data there gave 401
           before we knew refresh.data existed as a separate value.

Practical consequence: tokens.txt must hold BOTH the access token and the
refresh token. Losing the refresh token (14-day life) means only a password
login recovers; losing just the access token (65-min life) is normal and
recoverable via the refresh token at any time within its 14 days.

Usage
-----
    from gc_client import GCClient

    gc = GCClient.from_tokens_file(Path("tokens.txt"))
    box = gc.get_boxscore(game_id)
    plays = gc.get_plays(game_id)

Consumers: ingest/scrape_gamechanger.py (pipeline) and the MCP server
(interactive). Both sit on this; neither reimplements auth.
"""

from __future__ import annotations

import base64
import json
import os
import random
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import requests

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

API_ROOT = "https://api.team-manager.gc.com"
API_BASE_URL = f"{API_ROOT}/game-stream-processing"
AUTH_URL = f"{API_ROOT}/auth"

# The web client's registered application id. Same `cid` appears in both the
# client token and the user token, so it identifies the app, not the session.
CLIENT_ID = os.environ.get("GC_CLIENT_ID", "d6a83ac2-0963-4eb1-80d2-17a57d46bbf5")

# Credentials for full login. Never hardcode the password here.
GC_EMAIL = os.environ.get("GC_EMAIL", "")
GC_PASSWORD = os.environ.get("GC_PASSWORD", "")

# Unconfirmed. /auth discriminates on `type`; these are the plausible names for
# the rtkn exchange, tried in order on first refresh. The one that works is
# cached for the process lifetime. Reorder if you capture the real string.
REFRESH_TYPE = "refresh"

# Pause between refresh attempts (across header-shape candidates — see
# _refresh_candidates). Deliberately unhurried: hammering /auth previously
# produced a 500, and one candidate attempt already produced a clean,
# instant 500 that looked deterministic (wrong signing key in the wrong
# header) rather than flaky, so no automatic retry-on-same-shape is done —
# see refresh_with_refresh_token.
REFRESH_RETRY_BACKOFF = (1.5, 3.0)

# Refresh when the token has less than this many seconds of life left.
REFRESH_SKEW_SECS = 300

DELAY_WITHIN_GAME = (0.75, 1.5)
DELAY_BETWEEN_GAMES = (1.0, 3.0)
DELAY_BETWEEN_TEAMS = (55.0, 90.0)

_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
]

# GC dispatches on versioned vendor Accept types. Sending the wrong one (or a
# bare application/json) can yield a different shape or a 406, so each endpoint
# gets its exact type. Keyed by the last path segment of the URL.
# All values captured from real browser traffic (HAR, 2026-08-03).
_ACCEPT = {
    "boxscore": "application/vnd.gc.com.event_box_score+json; version=0.0.0",
    "plays": "application/json",
    "players": "application/vnd.gc.com.player:list+json; version=0.1.0",
    "game-summaries": "application/vnd.gc.com.game_summary:list+json; version=0.1.0",
    # /teams/public/{public_id}/id — resolves the short public id used in
    # web.gc.com URLs to the internal team UUID the above endpoints require.
    "id": "application/vnd.gc.com.team_id+json; version=0.0.0",
}


def jitter(low: float, high: float) -> None:
    time.sleep(random.uniform(low, high))


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class GCError(Exception):
    """Base for all client errors."""


class GCAuthError(GCError):
    """Token is expired/invalid and could not be renewed."""

    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


class GCNotFound(GCError):
    """Resource does not exist (HTTP 404)."""


# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------


def _decode_jwt_payload(token: str) -> dict:
    """Decode a JWT payload without verifying the signature.

    We are a client reading our own token's expiry, not validating a token we
    were handed by a third party, so signature verification is not meaningful
    here. Returns {} for anything that is not a readable three-part JWT.
    """
    try:
        part = token.split(".")[1]
        part += "=" * (-len(part) % 4)
        return json.loads(base64.urlsafe_b64decode(part))
    except Exception:
        return {}


@dataclass
class Credentials:
    """The access token plus the (separate) refresh token derived from it.

    Two different JWTs, two different lifetimes, two different signing keys.
    `token` is what goes on every API call. `refresh_jwt` is what renews it
    and is the more valuable of the two — it outlives `token` by ~300x.
    """

    token: str
    device_id: str
    refresh_jwt: str = ""
    source_file: Path | None = None
    claims: dict = field(default_factory=dict)
    refresh_claims: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.claims = _decode_jwt_payload(self.token)
        if self.refresh_jwt:
            self.refresh_claims = _decode_jwt_payload(self.refresh_jwt)

    # -- derived views ----------------------------------------------------

    @property
    def rtkn_id(self) -> str:
        """The access token's `rtkn` claim — a correlator, not a credential.

        Equal to the refresh JWT's `id` claim. Useful only for confirming the
        two tokens belong together; never send this value anywhere by itself.
        """
        return self.claims.get("rtkn", "")

    @property
    def has_refresh_token(self) -> bool:
        return bool(self.refresh_jwt)

    @property
    def user_id(self) -> str:
        return self.claims.get("userId", "")

    @property
    def expires_at(self) -> datetime | None:
        exp = self.claims.get("exp")
        if exp is None:
            return None
        return datetime.fromtimestamp(exp, tz=timezone.utc)

    @property
    def seconds_remaining(self) -> float:
        exp = self.expires_at
        if exp is None:
            # No exp claim means we cannot reason about lifetime. Treat as
            # live and let a 401 drive the refresh instead of guessing.
            return float("inf")
        return (exp - datetime.now(timezone.utc)).total_seconds()

    @property
    def refresh_expires_at(self) -> datetime | None:
        exp = self.refresh_claims.get("exp")
        if exp is None:
            return None
        return datetime.fromtimestamp(exp, tz=timezone.utc)

    def is_stale(self, skew: int = REFRESH_SKEW_SECS) -> bool:
        return self.seconds_remaining < skew

    # -- persistence ------------------------------------------------------

    @classmethod
    def from_file(cls, path: Path) -> "Credentials":
        if not path.exists():
            raise GCAuthError(
                f"tokens.txt not found at {path}\n"
                "Create it with:\n"
                "  gc-token: <your token>\n"
                "  gc-device-id: <your device id>"
            )

        token = device_id = refresh_jwt = ""
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or ":" not in line:
                continue
            key, _, val = line.partition(":")
            key = key.strip().lower()
            val = val.strip()
            if key == "gc-token":
                token = val
            elif key == "gc-device-id":
                device_id = val
            elif key in ("gc-refresh-token", "gc-refresh-jwt"):
                refresh_jwt = val

        missing = [k for k, v in (("gc-token", token), ("gc-device-id", device_id)) if not v]
        if missing:
            raise GCAuthError(f"tokens.txt is missing: {', '.join(missing)}")

        return cls(token=token, device_id=device_id, refresh_jwt=refresh_jwt, source_file=path)

    def save(self) -> None:
        if self.source_file is None:
            return
        lines = [f"gc-token: {self.token}", f"gc-device-id: {self.device_id}"]
        if self.refresh_jwt:
            lines.append(f"gc-refresh-token: {self.refresh_jwt}")
        try:
            self.source_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError as exc:
            print(f"  warn: could not write {self.source_file.name}: {exc}", file=sys.stderr)

    def apply(
        self,
        new_token: str,
        new_refresh_jwt: str | None = None,
        new_device_id: str | None = None,
    ) -> None:
        """Install a fresh access token and (when we got one) a fresh refresh token.

        `new_refresh_jwt=None` means "not returned this time" and leaves the
        existing one in place — the client-token stage returns no refresh
        token at all, and that must not wipe out a real one already on file.
        """
        self.token = new_token
        if new_device_id:
            self.device_id = new_device_id
        self.claims = _decode_jwt_payload(new_token)
        if new_refresh_jwt:
            self.refresh_jwt = new_refresh_jwt
            self.refresh_claims = _decode_jwt_payload(new_refresh_jwt)
        self.save()

    def describe(self) -> str:
        exp = self.expires_at
        if exp is None:
            access = "access: no exp claim"
        else:
            access = f"access: expires {exp.isoformat()} ({self.seconds_remaining/60:.0f} min left)"
        rexp = self.refresh_expires_at
        if rexp is None:
            refresh = "refresh: none on file"
        else:
            days = (rexp - datetime.now(timezone.utc)).total_seconds() / 86400
            refresh = f"refresh: expires {rexp.isoformat()} ({days:.1f} days left)"
        return f"{access} | {refresh}"


# ---------------------------------------------------------------------------
# Refresh strategies
# ---------------------------------------------------------------------------

RefreshFn = Callable[[Credentials], "TokenPair"]
"""Takes current credentials, returns a fresh TokenPair. Raises GCAuthError."""


def _auth_headers(device_id: str, bearer: str = "") -> dict:
    """Headers for an /auth POST.

    `bearer` is the gc-token header. On stage 1 it is empty; on stages 2 and 3
    it must be the client token, because the server correlates the handshake
    through that token's `sid` claim and nothing in the request body.
    """
    headers = {
        "content-type": "application/json",
        "accept": "application/json",
        "accept-language": "en-US,en;q=0.9",
        "gc-app-name": "web",
        "gc-device-id": device_id,
        "origin": "https://web.gc.com",
        "referer": "https://web.gc.com/",
        "user-agent": random.choice(_USER_AGENTS),
    }
    if bearer:
        headers["gc-token"] = bearer
    return headers


def _post_auth(
    payload: dict,
    device_id: str,
    bearer: str = "",
    extra_headers: dict | None = None,
    session: requests.Session | None = None,
) -> dict:
    """POST one stage to /auth and return the parsed body.

    Uses `session` when given so cookies set by one stage (e.g. client-auth,
    login) are sent back on the next (e.g. refresh). Every prior version of
    this function used a bare `requests.post` per call, which silently
    discards any Set-Cookie response header — if GC's refresh credential
    rides a cookie rather than a request header, no header guess could ever
    have worked regardless of which one we picked.
    """
    headers = _auth_headers(device_id, bearer)
    if extra_headers:
        headers.update(extra_headers)
    poster = session.post if session is not None else requests.post
    resp = poster(AUTH_URL, json=payload, headers=headers, timeout=15)
    if resp.status_code >= 400:
        raise GCAuthError(
            f"/auth type={payload.get('type')!r} failed: "
            f"HTTP {resp.status_code} {resp.text[:200]}",
            status=resp.status_code,
        )
    try:
        return resp.json()
    except ValueError as exc:
        raise GCAuthError(f"/auth returned non-JSON: {resp.text[:200]}") from exc


@dataclass
class TokenPair:
    access: str
    refresh: str | None  # None when this response didn't include one (client-token stage)


def _parse_token_response(body: dict) -> TokenPair:
    """Handle both response shapes seen from /auth.

    Nested envelope (password stage, refresh stage — confirmed from a real
    capture 2026-08):
        {"type": "token", "access": {"data": <jwt>, ...}, "refresh": {"data": <jwt>, ...}}

    Flat shape (client-auth stage):
        {"type": "client-token", "token": <jwt>, "expires": <epoch>}

    A prior version of this function only handled the flat shape and silently
    failed to find anything in the nested one — every real password login
    was broken until this was fixed.
    """
    if isinstance(body.get("access"), dict) and body["access"].get("data"):
        refresh = body.get("refresh")
        refresh_token = refresh.get("data") if isinstance(refresh, dict) else None
        return TokenPair(access=body["access"]["data"], refresh=refresh_token)

    for key in ("token", "gcToken", "accessToken", "access_token"):
        if body.get(key):
            return TokenPair(access=body[key], refresh=None)

    raise GCAuthError(f"No recognisable token in /auth response; keys were {sorted(body)}")


def get_client_token(
    device_id: str, client_id: str = CLIENT_ID, session: requests.Session | None = None
) -> str:
    """Stage 1 — anonymous client token. No user credentials involved."""
    body = _post_auth({"type": "client-auth", "client_id": client_id}, device_id, session=session)
    return _parse_token_response(body).access


def login(
    email: str,
    password: str,
    device_id: str,
    client_id: str = CLIENT_ID,
    session: requests.Session | None = None,
) -> TokenPair:
    """Full three-stage login. Returns (access_token, refresh_token).

    Guaranteed to work (it is exactly what the browser does) but requires the
    password, so it is the fallback rather than the default. Prefer
    refresh_with_refresh_token() once a refresh token is on file.

    `session` is threaded through all three stages so any Set-Cookie response
    (from client-auth or password) is carried forward. Untested whether GC
    actually uses cookies here, but there is no reason to keep discarding them
    while that is still an open question.
    """
    if not email or not password:
        raise GCAuthError(
            "Login needs GC_EMAIL and GC_PASSWORD (env vars or explicit args)."
        )

    client_token = get_client_token(device_id, client_id, session=session)
    # Stages 2 and 3 are correlated server-side via the client token's sid.
    _post_auth({"type": "user-auth", "email": email}, device_id, bearer=client_token, session=session)
    body = _post_auth(
        {"type": "password", "password": password}, device_id, bearer=client_token, session=session
    )
    pair = _parse_token_response(body)
    if not pair.refresh:
        raise GCAuthError(f"Login succeeded but response had no refresh token: keys were {sorted(body)}")
    return pair


# Candidate shapes for the refresh call, tried in order, ONE attempt each.
#
# The first candidate (refresh JWT as gc-token) produced a consistent 500 on
# all 3 attempts — not a 401. A 500 means the server crashed handling the
# request rather than cleanly rejecting a bad credential. The access and
# refresh JWTs are signed with different keys (different `kid`, confirmed by
# decoding both). If the refresh handler expects gc-token to hold an access
# token and tries to verify the refresh JWT against the access-token key,
# that would throw rather than fail gracefully — exactly a 500. So the
# refresh JWT is likely going in the wrong *slot*, not just rejected as
# wrong. These candidates try it in header names of its own, with and
# without the (possibly still-expired) access token alongside it, on the
# theory the server may need both to correlate the pair.
#
# Only 1 attempt per candidate — repeating an identical request that 500'd
# instantly is unlikely to succeed on retry, and burns the attempt budget on
# one already-falsified shape instead of testing others.
def _refresh_candidates(creds: Credentials) -> list[tuple[str, str, dict]]:
    """Returns (label, gc_token_header_value, extra_headers) tuples to try."""
    return [
        ("refresh-as-gc-token", creds.refresh_jwt, {}),
        ("refresh-header-only", "", {"gc-refresh-token": creds.refresh_jwt}),
        ("refresh-header+access-bearer", creds.token, {"gc-refresh-token": creds.refresh_jwt}),
        ("authorization-bearer", creds.token, {"authorization": f"Bearer {creds.refresh_jwt}"}),
    ]


def refresh_with_refresh_token(
    creds: Credentials, client_id: str = CLIENT_ID, session: requests.Session | None = None
) -> TokenPair:
    """Mint a fresh access+refresh pair from the existing refresh JWT. No password.

    Needs creds.refresh_jwt — the 14-day token from login's `refresh.data`,
    NOT the access token and NOT the `rtkn` claim (that's just an id, see
    Credentials.rtkn_id). Raises early if we don't have one on file yet; the
    only way to obtain one is a password login.

    STATUS: unresolved. Sweeps _refresh_candidates() once each. Also
    unexplained: the real browser's own refresh call failed ~9 times before
    succeeding, on presumably-valid credentials — not consistent with a clean
    "wrong credential" rejection either. That mechanism, whatever it is, is
    still not understood; this sweep is aimed at the 500 (wrong slot), not
    at reproducing the browser's retry count.
    """
    if not creds.refresh_jwt:
        raise GCAuthError("No refresh token on file — need one password login to obtain one.")

    payload = {"type": REFRESH_TYPE}
    errors: list[str] = []

    for label, bearer, extra in _refresh_candidates(creds):
        # One attempt per shape, no retry. A 500 that repeats instantly on
        # the first candidate looked deterministic (wrong key, not a
        # flaky server) — retrying an already-falsified shape wastes budget
        # that's better spent testing the next one. Total: 4 requests.
        try:
            body = _post_auth(
                payload, creds.device_id, bearer=bearer, extra_headers=extra, session=session
            )
            pair = _parse_token_response(body)
            print(f"  refresh shape confirmed: {label!r} — pin this in _refresh_candidates")
            return pair
        except GCAuthError as exc:
            errors.append(f"{label}: HTTP {exc.status}")
        jitter(*REFRESH_RETRY_BACKOFF)

    raise GCAuthError("All refresh shapes failed.\n  " + "\n  ".join(errors))


def _prompt_login_credentials(known_email: str = "") -> tuple[str, str]:
    """Ask for GC email/password at the terminal, password hidden via getpass.

    Exists because passing GC_PASSWORD through env vars is easy to get wrong
    (PowerShell's `set` silently doesn't set a real env var — creates a false
    "it's configured" impression) and leaves the password in shell history
    either way. Typed here, it goes straight into memory for this process
    only.
    """
    import getpass

    email = known_email
    if not email:
        email = input("  GC email: ").strip()
    password = getpass.getpass("  GC password (hidden): ")
    return email, password


def refresh_via_prompt(creds: Credentials) -> TokenPair:
    """v7 behaviour: pause and ask a human to paste a token.

    Retained only as the last-resort fallback. Non-interactive callers (the
    pipeline, the MCP server) must not use this — pass allow_prompt=False so
    they fail loudly instead of hanging on stdin.

    A pasted access token carries no refresh token, so this rung cannot renew
    refresh_jwt — only login() or refresh_with_refresh_token() do that.
    """
    if not sys.stdin.isatty():
        raise GCAuthError("Token expired and no interactive terminal is available.")

    print("\n" + "!" * 70)
    print("  TOKEN EXPIRED — paused.")
    print("  1. Open DevTools on web.gc.com")
    print("  2. Copy the 'gc-token' request header from any API call")
    print("!" * 70)

    new_token = ""
    while not new_token:
        new_token = input("\n  New gc-token: ").strip()

    new_device = input("  New gc-device-id (Enter to keep current): ").strip()
    if new_device:
        creds.device_id = new_device
    return TokenPair(access=new_token, refresh=None)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class GCClient:
    """Authenticated GameChanger API client with silent token renewal.

    Every request passes through _ensure_fresh() first, so a long batch scrape
    renews proactively rather than discovering expiry as a mid-run 401. A 401
    still triggers one reactive refresh-and-retry as a backstop for clock skew
    or server-side invalidation.
    """

    def __init__(
        self,
        creds: Credentials,
        refresh_fn: RefreshFn | None = None,
        allow_prompt: bool = True,
        verbose: bool = True,
        email: str = "",
        password: str = "",
    ) -> None:
        self.creds = creds
        self.email = email
        self.password = password
        self.allow_prompt = allow_prompt
        self.verbose = verbose
        self._refresh_fn = refresh_fn or self._default_refresh
        self._etags: dict[str, str] = {}
        self._refresh_count = 0
        self._used_password_login = False

        self.session = requests.Session()
        self.session.headers.update(
            {
                "accept-language": "en-US,en;q=0.9",
                "gc-app-name": "web",
                "referer": "https://web.gc.com/",
                "origin": "https://web.gc.com",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "priority": "u=1, i",
            }
        )
        self._apply_creds()

    @classmethod
    def from_tokens_file(cls, path: Path, **kwargs: Any) -> "GCClient":
        return cls(Credentials.from_file(path), **kwargs)

    # -- auth -------------------------------------------------------------

    def _apply_creds(self) -> None:
        self.session.headers.update(
            {"gc-token": self.creds.token, "gc-device-id": self.creds.device_id}
        )

    def _default_refresh(self, creds: Credentials) -> TokenPair:
        """Renewal ladder, each rung reached only if the one above fails:

          1. refresh-token exchange   — nothing needed beyond tokens.txt
          2. login via env vars       — GC_EMAIL / GC_PASSWORD, non-interactive
          3. login via typed password — interactive, getpass, TTY only
          4. paste-a-token prompt     — v7 behaviour, last resort
        """
        attempts = []

        try:
            # Reuse self.session (not a bare request) so any cookie the server
            # set earlier — at construction, at a prior login, at a prior
            # refresh — is sent back here.
            return refresh_with_refresh_token(creds, session=self.session)
        except GCAuthError as exc:
            attempts.append(f"refresh-token exchange: {exc}")
            self._log(f"  refresh-token exchange unavailable ({exc}); trying login")

        email = self.email or GC_EMAIL
        password = self.password or GC_PASSWORD
        if email and password:
            try:
                pair = login(email, password, creds.device_id, session=self.session)
                self._used_password_login = True
                return pair
            except GCAuthError as exc:
                attempts.append(f"login: {exc}")
        else:
            attempts.append("login: GC_EMAIL / GC_PASSWORD not set")

        # Interactive fallback: prompt for the password directly rather than
        # relying on an env var making it into this process. `set FOO=bar` in
        # PowerShell only creates a PS variable, not a real env var — an easy
        # way to burn a cycle thinking credentials are wired up when they
        # aren't. getpass doesn't echo and isn't stored in shell history.
        if self.allow_prompt and sys.stdin.isatty():
            try:
                email, password = _prompt_login_credentials(email)
                pair = login(email, password, creds.device_id, session=self.session)
                self._used_password_login = True
                return pair
            except GCAuthError as exc:
                attempts.append(f"interactive login: {exc}")
                # This used to fail silently into the paste-a-token prompt
                # below, hiding the real reason. Surface it now.
                self._log(f"  interactive login failed: {exc}")

        if self.allow_prompt:
            self._log(
                "  All automatic renewal attempts failed:\n    " + "\n    ".join(attempts)
            )
            return refresh_via_prompt(creds)

        raise GCAuthError("Could not renew token:\n  " + "\n  ".join(attempts))

    def _refresh(self) -> None:
        self._log("  refreshing token…")
        pair = self._refresh_fn(self.creds)
        self.creds.apply(pair.access, pair.refresh)
        self._apply_creds()
        self._refresh_count += 1
        self._log(f"  ok — {self.creds.describe()}")

    def _ensure_fresh(self) -> None:
        if self.creds.is_stale():
            self._refresh()

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg)

    # -- transport --------------------------------------------------------

    def _request(
        self, url: str, label: str, use_etag: bool = True, accept: str | None = None
    ) -> Any:
        self._ensure_fresh()

        # Accept type is looked up by the URL's last path segment; `accept`
        # overrides that for endpoints whose segment isn't a useful key
        # (e.g. /me/teams, which also carries a query string).
        endpoint = url.rstrip("/").split("/")[-1].split("?")[0]
        headers = {
            "accept": accept or _ACCEPT.get(endpoint, "application/json"),
            "user-agent": random.choice(_USER_AGENTS),
        }
        if use_etag and url in self._etags:
            headers["if-none-match"] = self._etags[url]

        resp = self.session.get(url, headers=headers, timeout=15)

        if resp.status_code == 401:
            # Proactive refresh should make this rare. When it fires anyway,
            # renew once and retry; a second 401 is a real auth failure.
            self._log(f"    {label}: 401 — renewing and retrying")
            self._refresh()
            headers["user-agent"] = random.choice(_USER_AGENTS)
            resp = self.session.get(url, headers=headers, timeout=15)
            if resp.status_code == 401:
                raise GCAuthError(f"{label}: still 401 after refresh")

        if resp.status_code == 404:
            raise GCNotFound(f"{label}: not found ({url})")

        if "etag" in resp.headers:
            self._etags[url] = resp.headers["etag"]

        if resp.status_code == 304:
            self._log(f"    ~ {label}: not modified (cached)")
            return None

        resp.raise_for_status()

        try:
            data = resp.json()
        except ValueError:
            self._log(f"    + {label}: {len(resp.text):,} chars (not JSON)")
            return resp.text

        self._log(f"    + {label}: {len(json.dumps(data)):,} chars")
        return data

    # -- public API -------------------------------------------------------

    def get_boxscore(self, game_id: str) -> Any:
        return self._request(f"{API_BASE_URL}/{game_id}/boxscore", "boxscore")

    def get_plays(self, game_id: str) -> Any:
        return self._request(f"{API_BASE_URL}/{game_id}/plays", "plays")

    def get_game(self, game_id: str) -> dict:
        """Fetch both grains for one game.

        Returns both boxscore and plays unconditionally. The warehouse plan
        (§4 silver) loads fact_play and fact_*_line independently and then
        reconciles them, so the client must never derive one from the other
        or skip one to save a request.
        """
        boxscore = self.get_boxscore(game_id)
        jitter(*DELAY_WITHIN_GAME)
        plays = self.get_plays(game_id)
        return {
            "game_id": game_id,
            "scraped_at": datetime.now().isoformat(),
            "boxscore": boxscore,
            "plays": plays,
        }

    # -- team-scoped endpoints --------------------------------------------
    #
    # These hang off the internal team UUID, NOT the short public id that
    # appears in web.gc.com URLs (e.g. hYwpOHgPHCsF). resolve_team_uuid()
    # converts one to the other. Passing a public id straight to these will
    # 404 in a way that looks like the team doesn't exist.

    def resolve_team_uuid(self, public_id: str) -> str:
        """Short public id (from a web.gc.com URL) -> internal team UUID.

        Works for any team, not just your own — this is the public lookup the
        web app itself uses. Pass-through if given something already
        UUID-shaped, so callers can hand it either form.
        """
        if len(public_id) == 36 and public_id.count("-") == 4:
            return public_id
        data = self._request(
            f"{API_ROOT}/teams/public/{public_id}/id", "id", use_etag=False
        )
        if isinstance(data, dict):
            for key in ("id", "team_id", "uuid"):
                if data.get(key):
                    return data[key]
        if isinstance(data, str) and data:
            return data.strip('"')
        raise GCError(f"Could not resolve team uuid from {public_id!r}: got {data!r}")

    def get_players(self, team: str) -> Any:
        """Team roster. Accepts a public id or a UUID.

        This is the authoritative roster straight from GC, as opposed to the
        roster the scraper infers from who appears in boxscores. Useful for
        the warehouse's dim_player / player_xref work (plan §5): players who
        never recorded a stat still appear here, and jersey/handedness data
        comes from the source rather than being reconstructed.
        """
        uuid = self.resolve_team_uuid(team)
        return self._request(f"{API_ROOT}/teams/{uuid}/players", "players")

    # -- public (non-manager) roster path ----------------------------------
    #
    # get_players() above is MANAGER-ONLY: it 403s for every team the account
    # doesn't manage, which is most of them. Found 2026-08-13 that the website
    # itself never calls it for other people's teams — it uses a parallel
    # /teams/public/... family keyed on the SHORT PUBLIC ID rather than the
    # resolved UUID. Same trailing path segment, completely different access
    # rules, which is why this took so long to spot:
    #
    #     manager-only:  /teams/{uuid}/players              -> 403 for others
    #     public:        /teams/public/{public_id}/players  -> works for any team
    #
    # The public roster carries id/first_name/last_name/number/avatar_url but
    # NO handedness; handedness lives one level down, per player, in
    # .../players/{player_uuid}/profile/stats under player.attributes.
    #
    # Caveat worth knowing before mining that profile payload for anything
    # else: its stats/spray-chart sections are premium-gated placeholder data
    # for a non-subscriber (has_premium=false, is_blurred=true, spray chart
    # ids are literally "fake-spray-N", and every player returns identical
    # stat lines). Only player.attributes and the game id/date list are real.

    def get_public_team(self, public_id: str) -> Any:
        """Team metadata via the public path. Works for teams you don't manage.

        Returns GC's own display name plus structured season info, e.g.

            {"id": "Gm7LE0Xeaozp", "name": "API Academy 11U",
             "age_group": "11U", "location": {...},
             "team_season": {"season": "fall", "year": 2025,
                             "record": {"win": 4, "loss": 10, "tie": 0}},
             "staff": [...], "player_count": 12}

        This is the right source for a team's NAME. Scraping it off the
        rendered page is not: the DOM selectors went stale at some point and
        every raw file written before 2026-09-06 carries
        team_name="GameChanger App" — the page <title>, silently picked up by
        the fallback path. An API field can't rot the same way.
        """
        return self._request(
            f"{API_ROOT}/public/teams/{public_id}", "team",
            use_etag=False, accept="application/json",
        )

    @staticmethod
    def team_name_from_meta(meta: Any) -> str:
        """Pull the display name out of a get_public_team() payload."""
        if isinstance(meta, dict):
            name = (meta.get("name") or "").strip()
            if name:
                return name
        return ""

    def get_public_players(self, public_id: str) -> Any:
        """Team roster via the public path. Works for teams you don't manage."""
        return self._request(
            f"{API_ROOT}/teams/public/{public_id}/players",
            "players", use_etag=False, accept="application/json",
        )

    def get_player_profile(self, public_id: str, player_uuid: str) -> Any:
        """One player's profile. `player.attributes` holds the handedness."""
        return self._request(
            f"{API_ROOT}/teams/public/{public_id}/players/{player_uuid}/profile/stats",
            "stats", use_etag=False, accept="application/json",
        )

    def public_roster_handedness(
        self, public_id: str, delay: tuple[float, float] = (0.15, 0.4)
    ) -> list[dict]:
        """Full roster WITH handedness for any team: 1 + N requests.

        One call for the roster, then one per player for the handedness.
        Individual player failures are swallowed and left blank rather than
        aborting the team — a missing profile must not cost us the roster.
        """
        roster = self.get_public_players(public_id)
        if not isinstance(roster, list):
            return []

        out: list[dict] = []
        for p in roster:
            if not isinstance(p, dict):
                continue
            first = (p.get("first_name") or "").strip()
            last = (p.get("last_name") or "").strip()
            uuid = p.get("id") or ""
            bat = throw = ""
            if uuid:
                try:
                    prof = self.get_player_profile(public_id, uuid)
                    attrs = ((prof or {}).get("player") or {}).get("attributes") or {}
                    bat = self._hand_code(attrs.get("batting_side"))
                    throw = self._hand_code(attrs.get("throwing_hand"))
                except Exception:
                    pass
                jitter(*delay)
            out.append({
                "player_uuid": uuid,
                "first_name": first,
                "last_name": last,
                "full_name": f"{first} {last}".strip(),
                "number": p.get("number"),
                "bat": bat,
                "throw": throw,
                "has_handedness": bool(bat or throw),
            })
        return out

    @staticmethod
    def handedness_yaml(players: list[dict]) -> str:
        """Render roster rows as _handedness.yaml.

        Same schema handedness_coverage() emits, plus the GC player uuid as a
        trailing comment — a far stronger join key than a name like "Alex D".
        Kept identical to what fetch_handedness_v2.py wrote for the existing
        83 files so build_bronze.py only ever parses one format.
        """
        lines = ["roster_handedness:\n\n"]
        for p in sorted(players, key=lambda x: x.get("full_name") or x.get("name") or ""):
            name = p.get("full_name") or p.get("name") or "(unnamed)"
            bat = p.get("bat") or "NA"
            throw = p.get("throw") or "NA"
            parts = []
            if p.get("player_uuid"):
                parts.append(f"person_id: {p['player_uuid']}")
            if not (p.get("bat") or p.get("throw")):
                parts.append("TODO — not in GC")
            comment = f"   # {'; '.join(parts)}" if parts else ""
            lines.append(f"  {name}:{comment}\n    bat: {bat}\n    throw: {throw}\n\n")
        return "".join(lines)

    def get_game_summaries(self, team: str) -> Any:
        """Per-game summary rows for a team. Accepts a public id or a UUID.

        Returns raw GC shape. Each row looks like:

            {"event_id": <uuid>,                 # == the game_id for boxscore/plays
             "game_stream": {"game_id": <uuid>, "game_status": "completed",
                             "home_away": "home", "opponent_id": <team uuid>, …},
             "owning_team_score": 6, "opponent_team_score": 9,
             "home_away": "home", "game_status": "completed",
             "last_scoring_update": "2026-05-03T17:17:58.864Z",
             "sport_specific": {"bats": {"total_outs": 36,
                                         "inning_details": {"inning": 7, "half": "top"}}}}

        See list_games() for a flattened, more usable view of the same data.
        """
        uuid = self.resolve_team_uuid(team)
        return self._request(f"{API_ROOT}/teams/{uuid}/game-summaries", "game-summaries")

    def list_games(self, team: str, completed_only: bool = True) -> list[dict]:
        """Flattened game list for a team — game_ids WITHOUT a browser.

        This is the important consequence of game-summaries: `event_id` is the
        same UUID that get_boxscore()/get_plays() take, so game discovery no
        longer needs Selenium at all. The schedule-page scrape remains useful
        only for the human-facing metadata GC doesn't return here (opponent
        NAME, venue, calendar date).

        Also surfaces `last_scoring_update`, which is the timestamp of the last
        scorekeeper edit. That is exactly the signal the warehouse's D2
        snapshot design was built around: GC scorekeepers correct games after
        the fact, and this makes "has this game changed since I last pulled it"
        answerable without re-fetching the whole payload.

        completed_only filters out scheduled/in-progress games, which have no
        meaningful boxscore yet — the same class of empty payload that produced
        the phantom-tie bug (plan §4).
        """
        rows = self.get_game_summaries(team)
        if not isinstance(rows, list):
            return []

        out: list[dict] = []
        for r in rows:
            if not isinstance(r, dict):
                continue
            stream = r.get("game_stream") or {}
            status = r.get("game_status") or stream.get("game_status") or ""
            if completed_only and status != "completed":
                continue
            us = r.get("owning_team_score")
            them = r.get("opponent_team_score")
            result = ""
            if isinstance(us, int) and isinstance(them, int):
                result = "W" if us > them else ("L" if us < them else "T")
            out.append(
                {
                    "game_id": r.get("event_id") or stream.get("game_id"),
                    "status": status,
                    "home_away": r.get("home_away") or stream.get("home_away"),
                    "our_score": us,
                    "opponent_score": them,
                    "result": result,
                    "opponent_team_id": stream.get("opponent_id"),
                    "last_scoring_update": r.get("last_scoring_update"),
                    "is_archived": stream.get("is_archived"),
                }
            )
        return out

    @staticmethod
    def _hand_code(value: Any) -> str:
        """GC's 'left'/'right'/'switch' -> the L/R/S codes roster_handedness.yaml uses.

        Returns "" for absent/unrecognised, which callers must treat as
        unknown rather than defaulting to right — assuming R would silently
        corrupt any pull/oppo spray analysis for the players GC has no data on.
        """
        v = (value or "").strip().lower()
        return {"left": "L", "right": "R", "switch": "S", "both": "S"}.get(v, "")

    @classmethod
    def flatten_players(cls, raw: Any) -> list[dict]:
        """Normalize the /players payload into flat roster rows.

        Raw shape per player (note `bats` is OPTIONAL — present for some
        players, absent for others on the same team):

            {"id", "team_id", "status", "first_name", "last_name", "number",
             "person_id",
             "bats": {"throwing_hand": "right", "batting_side": "right",
                      "player_id": …}}          # may be missing entirely

        `person_id` is the cross-team/cross-season identity — the same human on
        another team or in another season carries the same person_id, while
        `id` is per-team-membership. That makes person_id the natural stable
        key for the warehouse's dim_player, and is a far better basis for
        player_xref than the (team, name, jersey, season) composite the plan
        (§5) had to fall back on. Jersey numbers change and volunteer
        scorekeepers type names inconsistently; person_id does neither.

        Handedness is emitted as `bat`/`throw` in the same L/R/S vocabulary
        roster_handedness.yaml uses, with "" for unknown. Because GC's coverage
        is partial, that YAML becomes a FALLBACK for the gaps rather than the
        sole source — see handedness_coverage().
        """
        if not isinstance(raw, list):
            return []
        out = []
        for p in raw:
            if not isinstance(p, dict):
                continue
            first = (p.get("first_name") or "").strip()
            last = (p.get("last_name") or "").strip()
            bats = p.get("bats") if isinstance(p.get("bats"), dict) else {}
            bat = cls._hand_code(bats.get("batting_side"))
            throw = cls._hand_code(bats.get("throwing_hand"))
            out.append(
                {
                    "person_id": p.get("person_id") or p.get("id"),
                    "membership_id": p.get("id"),
                    "team_id": p.get("team_id"),
                    "first_name": first,
                    "last_name": last,
                    "full_name": f"{first} {last}".strip(),
                    "number": p.get("number"),
                    "status": p.get("status"),
                    "bat": bat,
                    "throw": throw,
                    "has_handedness": bool(bat or throw),
                }
            )
        return out

    @staticmethod
    def handedness_coverage(players: list[dict]) -> dict:
        """Split a flattened roster into players GC knows handedness for, and gaps.

        GC populates `bats` inconsistently, so this reports exactly who still
        needs a roster_handedness.yaml entry. `yaml_fragment` is ready to paste
        under the file's `roster_handedness:` key, pre-filled with the values
        GC does have and NA placeholders for the rest — so the manual step is
        editing a generated stub rather than transcribing a roster by hand.
        """
        known = [p for p in players if p.get("has_handedness")]
        missing = [p for p in players if not p.get("has_handedness")]

        lines = []
        for p in sorted(players, key=lambda x: x.get("full_name", "")):
            name = p.get("full_name") or "(unnamed)"
            bat = p.get("bat") or "NA"
            throw = p.get("throw") or "NA"
            flag = "" if p.get("has_handedness") else "   # TODO — not in GC"
            lines.append(f"  {name}:{flag}\n    bat: {bat}\n    throw: {throw}\n")

        return {
            "total": len(players),
            "with_handedness": len(known),
            "missing_handedness": len(missing),
            "missing_names": [p.get("full_name") for p in missing],
            "yaml_fragment": "roster_handedness:\n\n" + "\n".join(lines),
        }

    def get_my_teams(self) -> Any:
        """Teams on the authenticated account.

        Each row carries both `id` (UUID) and `public_id` (the short id in
        web.gc.com URLs), so this is also the mapping table between the two.
        """
        return self._request(
            f"{API_ROOT}/me/teams?include=user_team_associations",
            "me/teams",
            use_etag=False,
            accept="application/vnd.gc.com.team:list+json; version=0.10.0",
        )

    def whoami(self) -> Any:
        """Hit /me/user — the simplest authenticated call, no game_id needed.

        A 200 with the account back proves the token authenticates end to end
        against the live API. Use this to confirm a harvested token works
        before trusting the pipeline. (A 500 on a boxscore call with a made-up
        game_id proves nothing — that's the ID being invalid, not the token.)
        """
        return self._request("https://api.team-manager.gc.com/me/user", "me/user", use_etag=False)

    # -- diagnostics ------------------------------------------------------

    def status(self) -> dict:
        return {
            "user_id": self.creds.user_id,
            "device_id": self.creds.device_id,
            "expires_at": self.creds.expires_at.isoformat() if self.creds.expires_at else None,
            "minutes_remaining": round(self.creds.seconds_remaining / 60, 1),
            "has_refresh_token": self.creds.has_refresh_token,
            "refresh_expires_at": (
                self.creds.refresh_expires_at.isoformat() if self.creds.refresh_expires_at else None
            ),
            "login_credentials_available": bool(
                (self.email or GC_EMAIL) and (self.password or GC_PASSWORD)
            ),
            "refresh_type": REFRESH_TYPE,
            "refreshes_this_session": self._refresh_count,
        }

    def ping_auth(self) -> dict:
        """Single, minimal call to /auth — client-auth only, nothing else.

        Exists for exactly one purpose: checking whether /auth has recovered
        from a rate limit / abuse-protection block without risking another
        cascade of requests. probe_refresh() can fire 5+ requests in one call
        (the candidate sweep, then a full 3-stage login); this fires 1.

        A clean {"ok": true} here means /auth itself is healthy again and it
        is reasonable to try a real login. A 500 here — on the single
        simplest possible call, no credentials involved — means the block is
        still in effect; stop and wait longer rather than retrying.
        """
        try:
            token = get_client_token(self.creds.device_id, session=self.session)
        except GCAuthError as exc:
            return {"ok": False, "status": exc.status, "error": str(exc)}
        claims = _decode_jwt_payload(token)
        return {"ok": True, "sid": claims.get("sid", ""), "cid": claims.get("cid", "")}

    def probe_refresh(self) -> dict:
        """Diagnostic: attempt renewal now and report which rung worked.

        Run this once interactively before trusting an unattended scrape.
        Mints a real token as a side effect.

        Reports the session's cookie jar before and after. If GC sets a
        cookie during login or a prior call that the refresh call actually
        needs, `cookies_after` shows it directly — no DevTools round trip
        required to test that hypothesis.
        """
        cookies_before = dict(self.session.cookies)
        before = self.creds.token
        try:
            self._refresh()
        except GCAuthError as exc:
            return {
                "ok": False,
                "error": str(exc),
                "cookies_before": cookies_before,
                "cookies_after": dict(self.session.cookies),
            }
        return {
            "ok": True,
            "token_changed": self.creds.token != before,
            "used_password_login": self._used_password_login,
            "new_expiry": self.creds.expires_at.isoformat() if self.creds.expires_at else None,
            "cookies_before": cookies_before,
            "cookies_after": dict(self.session.cookies),
        }


# ---------------------------------------------------------------------------
# CLI: python gc_client.py [tokens.txt]  — prints credential status
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    flags = {a for a in sys.argv[1:] if a.startswith("-")}
    tokens_path = Path(args[0]) if args else Path("tokens.txt")

    client = GCClient.from_tokens_file(tokens_path, verbose=True)
    print(json.dumps(client.status(), indent=2))

    if "--check" in flags:
        # The real end-to-end test: does this token actually fetch data?
        print("\nCalling /me/user to verify the token authenticates…")
        try:
            me = client.whoami()
            name = ""
            if isinstance(me, dict):
                name = me.get("full_name") or me.get("email") or me.get("id") or ""
            print(f"  OK — token works. Account: {name or '(200, body parsed)'}")
        except GCNotFound:
            print("  Unexpected 404 — endpoint moved, but auth likely fine.")
        except GCAuthError as exc:
            print(f"  AUTH FAILED — token is not valid: {exc}")
        except Exception as exc:
            print(f"  Request error: {exc}")
    elif "--ping" in flags:
        # 1 request. Use this after a suspected rate limit, before --probe.
        print("\nPinging /auth (client-auth only, 1 request)…")
        print(json.dumps(client.ping_auth(), indent=2))
    elif "--probe" in flags:
        # Live network call. Determines which renewal rung actually works.
        # Can fire 5+ requests (candidate sweep + full login). If /auth was
        # recently rate-limited, run --ping first and confirm it's clean.
        print("\nProbing token renewal…")
        print(json.dumps(client.probe_refresh(), indent=2))
    else:
        print("\nRun with --check to verify the token fetches data (recommended),")
        print("--ping for a single lightweight /auth check,")
        print("or --probe to test full token renewal (several requests).")
