#!/usr/bin/env python3
r"""
fetch_handedness_v2.py — roster + handedness via the API instead of the browser

Why a v2
---------
v1 (fetch_handedness.py) drives a real logged-in Chrome and CLICKS every
roster row, because the manager-only /teams/{uuid}/players endpoint 403s
for every team the account doesn't manage. It works, but it's two page
loads per player (~14 players x ~85 team-seasons), and it inherits every
flakiness a live SPA has — silent no-op clicks, render races, rows that
only exist when the window is tall enough.

The endpoint v1 was working around
-----------------------------------
First guess (2026-08-13) was /teams/{uuid}/relationships, spotted as a
CORS preflight in the network panel. Probed it with the harvested token:
403, same as /players. That was the right answer to the wrong question —
/relationships is team-membership admin (join requests etc.), genuinely
manager-scoped, and only its OPTIONS preflight had been observed, never
a successful GET.

Reading the page's own resource-timing log instead of guessing from
preflights showed what the site really calls to render a roster for a
team the account does NOT manage:

    https://api.team-manager.gc.com/teams/public/{public_id}/players

Note how close that is to the endpoint we'd been failing on:

    manager-only:  /teams/{internal_uuid}/players     -> 403 for others
    public:        /teams/public/{public_id}/players  -> what the site uses

Same trailing segment, different path shape, different key (short public
id from the web.gc.com URL, not the resolved UUID), different access
rules. gc_client.get_players() resolves to the UUID form, which is why
every attempt through it 403'd and made the data look unreachable
without a browser session. It wasn't — we were just knocking on the
manager door.

CONFIRMED (live, 2026-08-13):
  - The public endpoint is what the site calls for a non-managed team,
    and the roster it returns is what renders on the page.
  - It is auth-gated but not manager-gated: unauthenticated returns 401.
    Our harvested token is a valid token for a logged-in account, which
    is what it should require. That is the make-or-break assumption and
    the probe tests it directly.

NOT CONFIRMED — what the probe is for:
  - Whether the payload carries handedness. The team page itself never
    displays bats/throws (only the per-player detail page does), so this
    may return roster identity only. If so it's still a win — person_id
    and jersey for all 85 team-seasons with no browser — but v1 stays
    the handedness path and we go find the per-player call.

Run --probe FIRST. It tries the public endpoint, the public team-meta
endpoint, and the known-403 manager endpoint as a control, then dumps
whatever comes back so the parser is written against reality. Guessing
at shapes is what made v1 take four rounds; not repeating that here.

Usage:
    # 1. Start here. Tries one team you do NOT manage, dumps what comes back.
    python fetch_handedness_v2.py --probe

    # ...or probe a specific team by its web.gc.com public id:
    python fetch_handedness_v2.py --probe --public-id qCtcYolEvr1D

    # 2. Only once the probe shows usable data:
    python fetch_handedness_v2.py --limit 3
    python fetch_handedness_v2.py

Flags mirror v1 where they overlap (--xref, --limit, --force) so the two
scripts are interchangeable from the caller's point of view.

v1 is NOT modified or replaced by this file. If the probe comes back
403, v1 remains the working path and nothing is lost.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from random import uniform
from time import sleep

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from gc_scraper import (  # noqa: E402
    RAW_ROOT,
    descriptor_from_url,
    team_id_from_url,
    season_from_descriptor,
    team_slug_from_descriptor,
)
from gc_client import GCClient, API_ROOT  # noqa: E402

DEFAULT_XREF = SCRIPT_DIR.parent / "seeds" / "team_xref.csv"
DEFAULT_TOKENS = SCRIPT_DIR / "tokens.txt"
PROBE_DIR = SCRIPT_DIR / "_probe"
PROBE_PLAYER_COUNT = 5          # how many players --probe pulls profiles for
DELAY_BETWEEN_PLAYERS = (0.15, 0.4)   # polite pacing; ~1 req/player

HAND_MAP = {"right": "R", "left": "L", "switch": "S", "both": "S"}


def hand_code(value) -> str:
    return HAND_MAP.get((value or "").strip().lower(), "") if isinstance(value, str) else ""


# ---------------------------------------------------------------------------
# The endpoint under test
# ---------------------------------------------------------------------------

def get_public_players(client: GCClient, public_id: str):
    """GET /teams/public/{public_id}/players — the roster call the website
    actually makes for a team you do NOT manage.

    Note the shape: keyed on the SHORT PUBLIC ID from the web.gc.com URL,
    under a /teams/public/ path. That is a different endpoint from
    gc_client.get_players(), which resolves to the internal UUID and hits
    /teams/{uuid}/players — the manager-only one that 403s for every team
    but your own. Same trailing path segment, completely different access
    rules. That collision is why this took so long to find.

    Goes through client._request so it inherits token refresh, retry and
    user-agent handling.
    """
    return client._request(
        f"{API_ROOT}/teams/public/{public_id}/players",
        "players",
        use_etag=False,
        accept="application/json",
    )


def get_public_team(client: GCClient, public_id: str):
    """GET /public/teams/{public_id} — team metadata, same public path."""
    return client._request(
        f"{API_ROOT}/public/teams/{public_id}", "team",
        use_etag=False, accept="application/json",
    )


def get_public_games(client: GCClient, public_id: str):
    """GET /public/teams/{public_id}/games — team game list, public path.

    Probed because the per-player profile payload carries an is_scrimmage
    flag per game that the v9 scrape never captured (checked 2026-08-13:
    6 of API Academy's 21 fall games are scrimmages, and they currently
    count toward W/L and season stats in bronze exactly like real games —
    including one half of a 2025-09-14 doubleheader where the other half
    is NOT a scrimmage, so it can't be inferred from the date).

    Getting it per-player costs one request per player. If this
    team-level endpoint carries the same flag it costs one request per
    TEAM instead (~85 vs ~1,000), which is why it's worth probing before
    building anything.
    """
    return client._request(
        f"{API_ROOT}/public/teams/{public_id}/games", "games",
        use_etag=False, accept="application/json",
    )


def get_player_profile(client: GCClient, public_id: str, player_uuid: str):
    """GET /teams/public/{public_id}/players/{uuid}/profile/stats

    Where handedness actually lives. Confirmed live (2026-08-13): loading
    a player detail page for a non-managed team fires exactly two
    player-related requests — the team roster, and this. The roster
    payload carries only id/first_name/last_name/number/avatar_url, so
    bats/throws has to come from here; it's the only other candidate,
    and the page renders "Bats: Right / Throws: Right" from it.

    This is the same 1-request-per-player shape v1 had, but as plain
    HTTP: no clicking, no render races, no window-height dependency.
    """
    return client._request(
        f"{API_ROOT}/teams/public/{public_id}/players/{player_uuid}/profile/stats",
        "stats", use_etag=False, accept="application/json",
    )


# Handedness field names, in the order to try. The roster endpoint uses a
# nested "bats" object (per gc_client.flatten_players); the profile
# endpoint's exact shape is dumped by --probe so this can be tightened.
def extract_handedness(payload) -> tuple[str, str]:
    """Pull (bat, throw) out of an arbitrary profile payload.

    Walks the structure rather than assuming a path — the profile
    response shape isn't pinned down yet, and a wrong assumption here
    would look exactly like "GC has no handedness for this player",
    which is the failure mode that wasted the most time on v1.
    """
    bat = throw = ""

    def walk(node):
        nonlocal bat, throw
        if isinstance(node, dict):
            for k, v in node.items():
                kl = k.lower()
                if isinstance(v, str):
                    if not bat and kl in ("batting_side", "bats", "bat", "batting_hand"):
                        bat = hand_code(v)
                    if not throw and kl in ("throwing_hand", "throws", "throw"):
                        throw = hand_code(v)
                else:
                    walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(payload)
    return bat, throw


# Candidate endpoints, in the order the probe should try them. Captured
# live (2026-08-13) from the resource-timing log of a team page for a team
# the account does not manage -- these are the calls the site itself makes.
PROBE_ENDPOINTS = [
    ("public players  (roster — the one that matters)",
     lambda c, pid, uuid: get_public_players(c, pid)),
    ("public team meta",
     lambda c, pid, uuid: get_public_team(c, pid)),
    ("public games    (is_scrimmage? see notes)",
     lambda c, pid, uuid: get_public_games(c, pid)),
    ("manager players (known to 403 — control)",
     lambda c, pid, uuid: c._request(f"{API_ROOT}/teams/{uuid}/players", "players",
                                     use_etag=False, accept="application/json")),
]


# ---------------------------------------------------------------------------
# Shape-tolerant parsing
#
# Written defensively ON PURPOSE: the response shape is unknown until the
# probe runs. Rather than assume a nesting, walk the payload for anything
# that looks like a person and pull the fields we recognise. Once the
# probe shows the real shape this can be replaced with a direct parser --
# but it should keep working either way.
# ---------------------------------------------------------------------------

NAME_KEYS = ("first_name", "last_name", "full_name", "name")


def _looks_like_player(d: dict) -> bool:
    if not isinstance(d, dict):
        return False
    has_name = any(k in d for k in NAME_KEYS)
    has_person = any(k in d for k in ("person_id", "player_id", "id"))
    return has_name and has_person


def _extract_player(d: dict) -> dict:
    first = (d.get("first_name") or "").strip()
    last = (d.get("last_name") or "").strip()
    full = (d.get("full_name") or d.get("name") or f"{first} {last}").strip()

    # handedness may be nested under "bats" (as /players does), or flat
    bats = d.get("bats") if isinstance(d.get("bats"), dict) else {}
    bat = hand_code(bats.get("batting_side") or d.get("batting_side") or d.get("bats"))
    throw = hand_code(bats.get("throwing_hand") or d.get("throwing_hand") or d.get("throws"))

    return {
        "person_id": d.get("person_id") or d.get("player_id") or d.get("id"),
        "name": full,
        "number": d.get("number") or d.get("jersey_number") or "",
        "status": d.get("status") or "",
        "bat": bat,
        "throw": throw,
    }


def parse_players(raw) -> list[dict]:
    """Walk an arbitrary JSON payload and collect player-shaped dicts."""
    found: list[dict] = []
    seen_ids: set = set()

    def walk(node):
        if isinstance(node, dict):
            if _looks_like_player(node):
                p = _extract_player(node)
                key = p["person_id"] or p["name"]
                if key and key not in seen_ids:
                    seen_ids.add(key)
                    found.append(p)
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(raw)
    return found


# ---------------------------------------------------------------------------
# xref / output plumbing — same conventions as v1 so both write identical files
# ---------------------------------------------------------------------------

def load_teams(xref_path: Path) -> list[dict]:
    teams = []
    with xref_path.open(encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            url = (row.get("schedule_url") or "").strip()
            if not url:
                continue
            descriptor = descriptor_from_url(url)
            season = row.get("season") or season_from_descriptor(descriptor)
            teams.append({
                "canonical_name": row.get("canonical_name"),
                "public_id": team_id_from_url(url),
                "descriptor": descriptor,
                "season": season,
                "team_slug": team_slug_from_descriptor(descriptor, season),
            })
    return teams


def find_snapshot_dir(season: str, team_slug: str) -> Path | None:
    team_dir = RAW_ROOT / season / team_slug
    if not team_dir.is_dir():
        return None
    date_dirs = sorted(d for d in team_dir.iterdir() if d.is_dir())
    return date_dirs[-1] if date_dirs else None


def is_already_complete(path: Path) -> bool:
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    return "roster_handedness:" in text and "TODO" not in text and text.strip() != "roster_handedness:"


def write_handedness_yaml(out_dir: Path, players: list[dict]) -> None:
    """Identical schema to v1 and to gc_client.handedness_coverage(), so
    downstream (build_bronze.py) never has to care which path filled it."""
    lines = ["roster_handedness:\n\n"]
    for p in sorted(players, key=lambda x: x.get("name") or ""):
        name = p.get("name") or "(unnamed)"
        bat = p.get("bat") or "NA"
        throw = p.get("throw") or "NA"
        parts = []
        if p.get("person_id"):
            parts.append(f"person_id: {p['person_id']}")
        if not (p.get("bat") or p.get("throw")):
            parts.append("TODO — not in GC")
        comment = f"   # {'; '.join(parts)}" if parts else ""
        lines.append(f"  {name}:{comment}\n    bat: {bat}\n    throw: {throw}\n\n")
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "_handedness.yaml").write_text("".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# Probe
# ---------------------------------------------------------------------------

def run_probe(client: GCClient, teams: list[dict], public_id: str | None) -> None:
    """Fetch ONE team and dump exactly what comes back.

    Defaults to a team from the xref rather than a managed one, because
    "works on the team you manage" is precisely the failure mode that
    made /players useless here — testing against a managed team would
    prove nothing.
    """
    if public_id:
        target = {"public_id": public_id, "descriptor": f"(explicit) {public_id}"}
    else:
        target = teams[0]

    print(f"Probing /relationships for: {target['descriptor']}  ({target['public_id']})")
    print("(a team from the xref — NOT one you manage, which is the whole test)\n")

    try:
        uuid = client.resolve_team_uuid(target["public_id"])
        print(f"resolved team uuid: {uuid}\n")
    except Exception as exc:
        print(f"✗ could not resolve team uuid: {type(exc).__name__}: {exc}")
        return

    PROBE_DIR.mkdir(parents=True, exist_ok=True)
    raw = None
    for label, call in PROBE_ENDPOINTS:
        try:
            data = call(client, target["public_id"], uuid)
        except Exception as exc:
            code = "403" if "403" in str(exc) else ("401" if "401" in str(exc) else "")
            print(f"  ✗ {label}: {code or type(exc).__name__}")
            continue
        slug = label.split("(")[0].strip().replace(" ", "_")
        out = PROBE_DIR / f"{slug}_{target['public_id']}.json"
        out.write_text(json.dumps(data, indent=2)[:2_000_000], encoding="utf-8")
        n = len(data) if isinstance(data, list) else "dict"
        print(f"  ✓ {label}: 200 — {n} item(s) → {out.name}")
        if raw is None and label.startswith("public players"):
            raw = data

    if raw is None:
        print("\n✗ The public roster endpoint did not return data. Stay on v1.")
        return

    print("\n✓ SUCCESS — the harvested token IS accepted on the PUBLIC roster")
    print("  endpoint for a team we do not manage. This is the path v1 was")
    print("  working around by clicking through the browser.")

    if isinstance(raw, dict):
        print(f"  top-level keys: {list(raw.keys())}")
    elif isinstance(raw, list):
        print(f"  top-level: list of {len(raw)} items")
        if raw and isinstance(raw[0], dict):
            print(f"  first item keys: {list(raw[0].keys())}")

    players = parse_players(raw)
    with_hand = [p for p in players if p["bat"] or p["throw"]]
    print(f"\n  players parsed: {len(players)}")
    print(f"  with handedness: {len(with_hand)}")
    if players:
        print("\n  sample rows:")
        for p in players[:5]:
            print(f"    {p['name']!r:28} #{p['number'] or '?':<4} "
                  f"bat={p['bat'] or '-'} throw={p['throw'] or '-'} person_id={p['person_id']}")

    # --- the part that actually decides whether v2 replaces v1 -------------
    if not players:
        return

    print("\n--- per-player profile/stats (where handedness lives) ---")
    probe_n = min(PROBE_PLAYER_COUNT, len(players))
    got = 0
    for p in players[:probe_n]:
        try:
            prof = get_player_profile(client, target["public_id"], p["person_id"])
        except Exception as exc:
            code = "403" if "403" in str(exc) else ("404" if "404" in str(exc) else type(exc).__name__)
            print(f"  ✗ {p['name']}: {code}")
            continue
        bat, throw = extract_handedness(prof)
        if bat or throw:
            got += 1
        print(f"  ✓ {p['name']:<24} bat={bat or '-'} throw={throw or '-'}")
        out = PROBE_DIR / f"profile_{target['public_id']}_{p['person_id'][:8]}.json"
        out.write_text(json.dumps(prof, indent=2)[:2_000_000], encoding="utf-8")

    print(f"\n  profile payloads written to {PROBE_DIR}")
    if got:
        print(
            "\n  → HANDEDNESS FOUND. v2 can fully replace v1: one roster call plus\n"
            "    one profile call per player, no browser at all."
        )
    else:
        print(
            "\n  ⚠️  Profile calls succeeded but no handedness parsed. Either these\n"
            "      particular players genuinely have none on file (API Academy is a\n"
            "      real candidate — v1 reported the same players as 'not in GC'), or\n"
            "      the field is named something this parser doesn't recognise.\n"
            "      Try:  --probe --public-id qCtcYolEvr1D   (Olney, known to have it)\n"
            "      If that's also blank, send me a profile_*.json and I'll pin the field."
        )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--xref", type=Path, default=DEFAULT_XREF)
    ap.add_argument("--tokens", type=Path, default=DEFAULT_TOKENS)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--probe", action="store_true",
                    help="fetch ONE team and dump the raw payload; run this first")
    ap.add_argument("--public-id", default=None, help="probe this specific team")
    args = ap.parse_args()

    if not args.tokens.exists():
        sys.exit(f"No tokens file at {args.tokens}. Run: python gc_harvest.py")

    teams = load_teams(args.xref)
    client = GCClient.from_tokens_file(args.tokens)

    if args.probe:
        run_probe(client, teams, args.public_id)
        return

    if args.limit:
        teams = teams[: args.limit]
    print(f"Loaded {len(teams)} team-season(s) from {args.xref}", flush=True)

    done = skipped = failed = 0
    no_dir: list[str] = []

    for i, team in enumerate(teams, 1):
        descriptor = team["descriptor"]
        snap_dir = find_snapshot_dir(team["season"], team["team_slug"])
        if snap_dir is None:
            print(f"[{i}/{len(teams)}] {descriptor}: no raw snapshot dir — skipped", flush=True)
            no_dir.append(descriptor)
            continue

        path = snap_dir / "_handedness.yaml"
        if not args.force and is_already_complete(path):
            print(f"[{i}/{len(teams)}] {descriptor}: already complete — skipped", flush=True)
            skipped += 1
            continue

        try:
            raw = get_public_players(client, team["public_id"])
            players = parse_players(raw)
        except Exception as exc:
            print(f"[{i}/{len(teams)}] {descriptor}: ✗ {type(exc).__name__}: {exc}", flush=True)
            failed += 1
            continue

        if not players:
            print(f"[{i}/{len(teams)}] {descriptor}: ⚠️  no players parsed from payload", flush=True)
            failed += 1
            continue

        # Roster gives identity + jersey; handedness needs one call each.
        errs = 0
        for p in players:
            if not p["person_id"]:
                continue
            try:
                prof = get_player_profile(client, team["public_id"], p["person_id"])
            except Exception:
                errs += 1
                continue
            p["bat"], p["throw"] = extract_handedness(prof)
            sleep(uniform(*DELAY_BETWEEN_PLAYERS))

        known = sum(1 for p in players if p["bat"] or p["throw"])
        if errs:
            print(f"    ({errs} profile call(s) failed)", flush=True)
        write_handedness_yaml(snap_dir, players)
        print(f"[{i}/{len(teams)}] {descriptor}: ✓ {known}/{len(players)} with handedness", flush=True)
        done += 1

    print(f"\nDone. {done} written, {skipped} already complete, {failed} failed, "
          f"{len(no_dir)} missing a raw snapshot dir.", flush=True)


if __name__ == "__main__":
    main()
