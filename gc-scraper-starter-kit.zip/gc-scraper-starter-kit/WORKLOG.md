# Worklog — development history of this scraper (v9)

This is the running changelog from the original project, kept close to
as-written because it explains *why* the code looks the way it does —
several things in here read like bugs to a fresh pair of eyes but are
deliberate fixes for real GameChanger quirks.

A few things it references belong to the larger project this was pulled
from and aren't part of this starter kit: `seeds/team_xref.csv`,
`warehouse/` (a downstream DuckDB pipeline), `team list.xlsx`, and
`batch_1.txt..batch_4.txt` (a large multi-team batch split). Treat those
mentions as historical context, not paths that exist here. batch.txt in
this kit has one working example URL instead.

---

GameChanger Scraper v9 — usage
================================

Same setup as v8:

  1. launch_chrome_debug.bat -> log in to web.gc.com once
  2. python gc_harvest.py --out tokens.txt  -> writes a fresh token
  3. python gc_scraper.py batch_1.txt       -> scrapes that batch

What changed from v8
---------------------
- Every team-season now also pulls the authoritative roster (person_id,
  handedness where GC has it) via the API and writes it to _players.json
  next to the season file. This is GC's own stable cross-team/cross-season
  player identity -- the fix for the "missing players" gap.
- Output moved from a flat per-run folder into a proper snapshot-dated
  archive:
      raw/gamechanger/{season}/{team_slug}/{scrape_date}/
  Re-running never overwrites a prior day's pull -- each run gets its own
  dated subfolder.
- You can now point the scraper at a specific batch file as a CLI arg
  (batch_1.txt .. batch_4.txt), instead of always reading batch.txt. Run
  each one as its own session -- convenient for spacing a big pull out or
  picking back up after a reboot.

Schedule scraping (Selenium, for date/opponent-name/venue) and the
per-game boxscore/plays fetch (API) are unchanged from v8 -- both already
worked.

Failure handling (added after the first real run hit a 404 mid-batch)
-----------------------------------------------------------------------
- A single game 404ing no longer kills the run -- it's skipped, and the
  scrape continues. Recorded three ways: in the team's own season JSON
  (top-level "failed_games"), in a plain-text _failed_games.txt next to
  that team's other output files, and appended to one cumulative log:
      raw/gamechanger/_scrape_failures.txt
  That log is append-only and never overwritten, so it accumulates across
  all 4 batches and any future re-runs. Each line is tab-separated
  (kind, team_id, season, game_id, date, opponent, schedule_url, error) --
  enough for a later Claude/MCP session to look each one up with
  gc_get_game / gc_find_game / gc_snapshot_team_api and re-pull it.
- A whole team's schedule failing unexpectedly (not just one game) is
  logged the same way (kind=team) and the batch moves on to the next team
  instead of stopping. A real auth failure (dead token) still stops the
  run immediately, since retrying won't help until you re-harvest.

Root cause found (2026-08-11) and fixed
------------------------------------------
The first real run crashed on a 404 fetching a game's boxscore. Checked
every failure in _scrape_failures.txt against GC's API (gc_get_games) for
the 7 affected teams via the gamechanger MCP: none of the failed game_ids
existed in GC's authoritative completed-games list at all -- they were
schedule-page links for slots that never became real games (TBD/rescheduled/
canceled; one was still literally labeled opponent="TBD"). Not a bug in the
fetch code, a phantom in what the schedule page rendered.

Fix: before fetching, run_schedule() now cross-checks every schedule-page
game_id against client.list_games() (the API, no Selenium). Anything not in
that authoritative set is skipped and logged as kind=phantom_schedule_entry
-- never even attempted, so no more crash-on-404. It also checks the other
direction: a real completed game the API knows about that the schedule-page
scrape didn't surface gets logged as kind=missing_from_schedule_page (a
coverage gap) -- flagged, not auto-fetched, since it has no date/opponent
metadata without the schedule page. Worth a look in _scrape_failures.txt
after a full run.

Raw-data quirks found building bronze (2026-08-12)
-----------------------------------------------------
Two GC quirks found while loading this scraper's output into DuckDB (see
warehouse/bronze-walkthrough.md for the full writeup). Full detail is now
in gc_scraper.py's module docstring too. Short version:

- boxscore.<side>.pitching_players[].stats.IP is baseball dot notation
  (1.1 = 1 out, not 1.1 decimal innings) -- same as season_stats.pitching.
  The sibling team-total field, pitching_totals.IP, is a genuinely
  different convention: true decimal thirds (5.666... = 5-and-2/3 innings).
  Mixing these up silently undercounts fractional-inning outings.
- A game GC is actively broadcasting live at the moment of the scrape can
  show opponent="LIVE" with the real opponent name sitting in the
  location field instead ("vs. <team>"). Box score/plays for that game can
  still be complete and correct -- only those two display fields are wrong.

API Academy spring 2026 hit both the zero-stat-game and the "LIVE" case in
the same file. Since that team isn't expected to be reharvested, its raw
JSON was hand-corrected on 2026-08-12 (one zero-stat game removed, the
"LIVE" game's opponent/location/result fixed from data already in the
file) -- see that file's metadata.manual_corrections for the full audit
trail. This is a deliberate one-off exception to "raw/ is never
hand-edited" (D1/D2), made because no future scrape will fix it naturally.
build_bronze.py also now omits any zero-stat game (blank result, all-zero
box score both sides) from bronze_games automatically, logging it to
bronze_omitted_games instead, so this doesn't require a hand-patch for any
other team that hits the same pattern.

Roster + handedness for teams you DON'T manage (2026-08-13)
-------------------------------------------------------------
v9 originally pulled the roster from /teams/{uuid}/players. That endpoint
is manager-only: it 403s for every team except the ones on your account,
so ~80 of 83 team-seasons had no roster and no handedness at all.

The fix was finding that web.gc.com never calls that endpoint for other
people's teams. It uses a parallel PUBLIC family keyed on the short
public id from the URL instead of the resolved UUID:

    manager-only:  /teams/{uuid}/players                    -> 403 for others
    public:        /teams/public/{public_id}/players        -> any team
    handedness:    /teams/public/{public_id}/players/{player_uuid}/profile/stats
                     -> player.attributes.batting_side / .throwing_hand

Same trailing path segment on the first two, completely different access
rules -- that collision is why it went unnoticed for so long. Both are
auth-gated (401 unauthenticated) but NOT manager-gated, so the ordinary
harvested token works fine.

This is now built into gc_scraper.py: every team-season scrape calls
gc_client.public_roster_handedness() and writes _handedness.yaml
automatically. It tries the manager endpoint first as well, since that
one (and only that one) returns person_id, GC's stable cross-season
identity. For your own teams you get both; for everyone else's you get
the public half.

fetch_handedness_v2.py is the standalone backfill/probe version of the
same thing -- use it to re-pull handedness without redoing a full scrape,
or `--probe` to inspect raw endpoint payloads.

Current coverage: 83 teams, 1,027 players, 805 (78%) with handedness.
The missing 23% is a genuine gap in GC's data, NOT a scrape failure --
verified by running the manager-scoped endpoint against BCC Big Train
(a team we DO manage) and getting the identical 5-of-14. Never default a
blank to R; a wrong hand silently corrupts pull/oppo spray analysis.

Coach-supplied handedness overrides (2026-08-14)
--------------------------------------------------
For teams where GC has no handedness but a human knows it, a coach-maintained
file is the source of truth. BCC Big Train is the first: BCC_roster_handedness.yaml
in this folder. Deliberate exception to "raw/ is never hand-edited", same
reasoning as the API Academy patch -- GC has no handedness for most of that
roster, so no rescrape will ever fix it. Every value GC did have matched the
coach file exactly (zero conflicts across 24 rows), a decent signal the file
is trustworthy.

This is now AUTOMATIC. gc_scraper.py calls handedness_overrides.py right after
writing _handedness.yaml, so a rescrape can no longer silently revert coach
values to NA -- which matters with frequent rescrapes coming next season.

To add another team, drop a file in this folder (or handedness_overrides/)
named *_roster_handedness.yaml with a team_slug header:

    # team_slug: crofton-cardinals-11u
    roster_handedness:
      Mack A:
        bat: R
        throw: L

The team_slug binds it to that team's raw/ folders and covers EVERY season of
that team. A file without the header is skipped with a warning rather than
guessed at.

It merges rather than replacing: only bat/throw come from the override, while
GC player uuids (the only reliable join key -- names like "Alex D" collide
across teams) and roster entries absent from the override (e.g. the "Guest 1"
/"Guest 2" placeholders) are preserved. Conflicts, where GC has a value and
the override disagrees, are printed rather than silently resolved; the coach
value wins.

Manual sweep, if you edit an override file outside of a scrape:

    python handedness_overrides.py --dry-run   # preview
    python handedness_overrides.py             # apply to all of raw/
    python ../warehouse/build_bronze.py        # reload bronze

Safe to run repeatedly -- re-applying an already-applied override reports
"0 changed".

Do NOT mine that profile/stats payload for anything besides handedness.
Its stats and spray-chart sections are premium-gated placeholders for a
non-subscriber: has_premium=false, is_blurred=true, spray chart ids are
literally "fake-spray-1/2/3", and every player on a team returns
byte-identical stat lines (AB=4, H=1, PS=12, SW=7). Only
player.attributes and the game id/date list are real, and the game list
adds nothing -- all 21 event_ids checked already matched bronze_games
exactly.

An earlier Selenium approach (fetch_handedness.py) clicked through every
roster row in a live browser to get the same data. It works and is kept
as a fallback, but it's ~2,400 page loads instead of ~1,100 API calls and
is subject to render races. Prefer the API path.

Two metadata bugs found and fixed 2026-09-06
----------------------------------------------
1. A schedule URL WITHOUT the descriptor segment
   (https://web.gc.com/teams/<id>/schedule, which is what you get copying the
   address bar at the wrong moment) filed its snapshot under
   raw/gamechanger/<team_id>/<team_id>/<date>/. descriptor_from_url() fell back
   to the bare id, then season_from_descriptor() saw no leading year and
   returned that id as the "season". Silent -- the scrape itself succeeds and
   the data is correct, it's just filed under a season named after the team id,
   which build_bronze.py would load as if it were real.

   Fixed: the scraper now reads GC's own canonical descriptor off the rendered
   page's nav links (they always carry the full
   /teams/<id>/2026-fall-wild-bill-12u-hunter/... form) and redoes the season /
   team_slug derivation before anything is written. It deliberately does NOT
   reconstruct a slug from the team name -- GC drops parentheses and turns
   " - " into "---", and a near-miss would just create a second wrong folder.
   If no descriptor can be recovered the team is skipped and logged rather than
   misfiled.

   The one team this hit (Wild Bill 12u (Hunter), fall 2026) has been relocated
   to 2026-fall/wild-bill-12u-hunter/ with its metadata repaired; see that
   file's manual_corrections.

2. metadata.team_name was "GameChanger App" in ALL 131 raw files -- the page
   <title>. _TEAM_NAME_JS reads the name via CSS-class selectors, GC renamed
   those classes, so it returned "" every time and the title fallback took
   over unnoticed.

   Fixed: the name now comes from GC's API (/public/teams/{public_id} ->
   "name"), which can't go stale the way a class selector does. The page value
   is kept only as a fallback.

   To repair files already on disk (worth doing -- 2025-fall and 2026-spring
   won't be rescraped):

       python backfill_team_names.py --dry-run
       python backfill_team_names.py

   One API call per distinct team (129), not per file. It only overwrites the
   known placeholder values and records each change in that file's
   manual_corrections.

Batch lists
-----------
batch_1.txt .. batch_4.txt were generated from the repaired team list
(team list-21003eb4.xlsx) plus the resolved fall<->spring pairing --
see ../seeds/team_xref.csv and ../seeds/team_xref_review_notes.md for how
those pairs were derived and what's still flagged for your confirmation.

Each batch groups a team's fall + spring URLs together (so a reboot
mid-batch doesn't leave a team half-scraped across two runs) and is sized
to ~20-21 schedule URLs (83 URLs total across the 4 files, covering the
Fall 2025 + Spring 2026 locked cohort). The 2026-fall District
Diamondbacks early-registration row and the two Ayra Athletics quirks are
called out in the review notes -- read that before running batch_1.

Uses Selenium, same as v8.
