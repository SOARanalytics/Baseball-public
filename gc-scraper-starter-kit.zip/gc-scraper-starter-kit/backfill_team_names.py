#!/usr/bin/env python3
r"""
backfill_team_names.py — repair metadata.team_name in already-scraped raw files

The bug
--------
gc_scraper.py read the team name off the rendered schedule page via
_TEAM_NAME_JS, whose selectors are CSS-class based. GC renamed those classes
at some point, so the function returned "" and the <title> fallback took
over — writing metadata.team_name = "GameChanger App" (the page title) into
every raw season file. Found 2026-09-06: all 131 files on disk had it.

Nothing downstream broke, because foldering keys off the URL descriptor, not
the name. But it means the archive carries no real team names, which silver
wants for team_xref and for anything human-readable.

gc_scraper.py now takes the name from GC's API instead
(/public/teams/{public_id} -> "name"), which can't go stale the way a CSS
selector does. That fixes future scrapes. This script fixes the ones already
on disk — worth running because the older seasons (2025-fall, 2026-spring)
won't be rescraped.

What it does
-------------
For each raw season JSON: read metadata.team_id, ask the API for the team's
real name, and rewrite metadata.team_name if it's missing or is the known
"GameChanger App" placeholder. A team_name that is neither is left alone and
reported, on the assumption a real value shouldn't be clobbered by a script.

Every change is recorded in that file's metadata.manual_corrections, same
audit-trail convention used for the API Academy and Wild Bill repairs.

Usage:
    python backfill_team_names.py --dry-run    # show what would change
    python backfill_team_names.py
"""

from __future__ import annotations

import argparse
import datetime
import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from gc_client import GCClient  # noqa: E402

DEFAULT_RAW_ROOT = SCRIPT_DIR / "raw" / "gamechanger"
DEFAULT_TOKENS = SCRIPT_DIR / "tokens.txt"

# The page-<title> value that leaked in. Safe to overwrite; anything else is not.
PLACEHOLDER_NAMES = {"", "GameChanger App", "GameChanger"}


def season_json_files(raw_root: Path):
    """Every team-season JSON (excludes _players.json / _handedness.yaml)."""
    for path in sorted(raw_root.glob("*/*/*/*.json")):
        if path.name.startswith("_"):
            continue
        yield path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root", type=Path, default=DEFAULT_RAW_ROOT)
    ap.add_argument("--tokens", type=Path, default=DEFAULT_TOKENS)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if not args.tokens.exists():
        sys.exit(f"No tokens file at {args.tokens}. Run: python gc_harvest.py")

    client = GCClient.from_tokens_file(args.tokens)
    today = datetime.date.today().isoformat()

    # One API call per distinct team id, not per file — the same team appears
    # once per season and the name doesn't change between them.
    name_cache: dict[str, str] = {}
    fixed = skipped = failed = untouched = 0

    for path in season_json_files(args.raw_root):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"  ⚠️  {path.name}: unreadable ({type(exc).__name__}) — skipped")
            failed += 1
            continue

        meta = data.get("metadata") or {}
        team_id = meta.get("team_id") or ""
        current = (meta.get("team_name") or "").strip()

        if current not in PLACEHOLDER_NAMES:
            untouched += 1
            continue
        if not team_id:
            print(f"  ⚠️  {path.name}: no team_id in metadata — skipped")
            failed += 1
            continue

        if team_id not in name_cache:
            try:
                name_cache[team_id] = client.team_name_from_meta(
                    client.get_public_team(team_id)
                )
            except Exception as exc:
                print(f"  ⚠️  {team_id}: API lookup failed ({type(exc).__name__})")
                name_cache[team_id] = ""
        real = name_cache[team_id]

        if not real:
            failed += 1
            continue

        rel = "/".join(path.parts[-4:-1])
        if args.dry_run:
            print(f"  would set {rel:52} {current!r} -> {real!r}")
            fixed += 1
            continue

        meta["team_name"] = real
        meta.setdefault("manual_corrections", []).append({
            "date": today,
            "reason": "metadata.team_name held the page <title> ('GameChanger App') "
                      "because _TEAM_NAME_JS's CSS selectors went stale. Repaired "
                      "from GC's API (/public/teams/{id} -> name) by "
                      "backfill_team_names.py.",
            "before": {"team_name": current},
            "after": {"team_name": real},
        })
        data["metadata"] = meta
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"  ✓ {rel:52} -> {real!r}")
        fixed += 1

    verb = "would fix" if args.dry_run else "fixed"
    print(f"\n{verb} {fixed}, left alone {untouched} (already had a real name), "
          f"{failed} failed, {skipped} skipped.")
    if fixed and not args.dry_run:
        print("Re-run warehouse/build_bronze.py if you want it reflected in bronze.")


if __name__ == "__main__":
    main()
