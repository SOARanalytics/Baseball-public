# GameChanger Scraper — Quick Start

## What this is
Scrapes GameChanger (web.gc.com) baseball data — schedules, box scores,
play-by-play, rosters, and handedness — for any team whose schedule page
you can view, not just teams you manage.

## The trick that makes it work
GameChanger's `/auth` endpoint requires a signed request (`gc-signature`)
computed from a secret buried in their obfuscated JS. You cannot mint or
refresh a token from a plain script — don't try to reverse-engineer this,
it's adversarial and GC rotates it. But the *data* endpoints (boxscore,
plays, roster) only need the token itself, unsigned. So instead of faking
auth, this harvests the live token straight out of a real, logged-in
browser tab via the Chrome DevTools Protocol, and lets the browser do the
signed refreshing (every ~55 min) on its own. Full writeup in WORKLOG.md
and in gc_client.py's module docstring.

## Setup
1. Python 3.10+.
2. `pip install -r requirements.txt`
3. Google Chrome installed. Selenium 4.6+ auto-manages its own driver
   (Selenium Manager) as long as Chrome itself is present — no separate
   chromedriver download needed in most cases.
4. `launch_chrome_debug.bat` looks for chrome.exe in the usual Program
   Files locations. Edit the `CHROME=` line near the top if yours is
   somewhere else.

## Running it — three steps, every session
1. Double-click `launch_chrome_debug.bat`. It opens a **dedicated** Chrome
   profile (separate from your normal browsing) with a debug port open.
   Log in to https://web.gc.com in that window once, then leave it open.
2. In a terminal in this folder:
   `python gc_harvest.py --out tokens.txt`
   Reads the live `gc-token` off that browser's own traffic and writes it
   to tokens.txt. Add `--watch` to keep it running and auto-refresh
   tokens.txt whenever the browser's token rotates — useful for a long
   scrape session.
3. `python gc_scraper.py batch.txt`
   batch.txt is plain text, one GameChanger schedule URL per line. There's
   one real example URL in there already (a BCC Big Train schedule) so you
   can run the whole pipeline end-to-end before pointing it at your own
   team. Find a schedule URL by opening any team's page on web.gc.com and
   copying the `.../schedule` URL — you don't need to manage that team to
   scrape it.

Output lands in `raw/gamechanger/{season}/{team_slug}/{scrape_date}/` — a
fresh dated subfolder every run, so re-running never overwrites a prior
pull. Each team-season folder gets the schedule/box score/play-by-play
JSON, `_players.json` (roster keyed on GC's stable person_id), and
`_handedness.yaml` (batting/throwing hand where GC has it).

## tokens.txt
Ships empty in this kit. gc_harvest.py creates/overwrites it every run —
you don't normally touch it by hand.

**Manual fallback** (if the harvester can't reach Chrome for some reason):
open DevTools on web.gc.com → Network tab → click any request to
`api.team-manager.gc.com` → Headers → copy the `gc-token` value (and
`gc-device-id`, same panel) → paste into tokens.txt as:

    gc-token: <value>
    gc-device-id: <value>

This is exactly what gc_client.py's own error message tells you to do if
tokens.txt is missing or incomplete when you run the scraper.

## Known quirks worth knowing before you extend this
Full history in WORKLOG.md — the two most likely to bite you first:
- `boxscore.<side>.pitching_players[].stats.IP` is baseball notation
  (1.1 = one out), but the sibling `pitching_totals.IP` is true decimal
  thirds (5.666... = 5-and-2/3). Mixing these up silently undercounts
  fractional-inning outings.
- Roster/handedness for teams you don't manage comes from a separate
  **public** endpoint family (`/teams/public/{public_id}/...`), not the
  manager-only one. Already wired into gc_scraper.py — worth knowing it
  exists if you ever hit an unexplained 403 on roster data.

## Bonus utilities (not required to run the core scraper)
- `fetch_handedness_v2.py` — standalone handedness backfill/probe; re-pull
  just handedness without a full rescrape.
- `backfill_team_names.py` — one-off repair tool for a specific naming
  bug (see WORKLOG.md); included as a reference for the kind of
  hand-repair tooling this project ended up needing.
