# Context prompt — paste this into a new Claude session to get started

I'm starting a project from a GameChanger (web.gc.com) baseball scraper
someone else built and handed off to me. Before making any changes, read:

1. QUICKSTART.md — what it does and how to run it.
2. WORKLOG.md — the development history: what was built, in what order,
   and why. It documents several non-obvious fixes (a token-auth
   workaround, phantom schedule entries, two metadata bugs) that would
   look like bugs worth "fixing" to someone who doesn't know they're
   deliberate.
3. The module docstrings at the top of gc_client.py and gc_scraper.py —
   both have detailed inline explanations of the trickiest parts: the
   auth signature barrier, the IP-notation quirk, and the public-vs-manager
   roster endpoints.

The single most important thing to understand before touching anything
auth-related: GameChanger's `/auth` endpoint requires a signed request
that cannot be produced from a plain script. Do NOT attempt to
reimplement or work around that signature — it's adversarial and they
rotate it. The existing design instead harvests a live token out of a
real, logged-in Chrome tab (gc_harvest.py). That's the intended path, not
a placeholder for "real" auth — don't replace it without a good reason.

My immediate goal is: [fill this in — e.g. point this at a different
league or sport, add a new data field, build an analysis layer on top of
what it scrapes]. Read the worklog and the two docstrings first, then
tell me what you'd change and why before writing any code.
