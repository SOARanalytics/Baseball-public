#!/usr/bin/env python3
"""
GameChanger Scraper v9
Scrapes schedule + boxscore + play-by-play, processes everything inline,
and writes one clean JSON per team/season into a snapshot-dated raw/ archive.

v9 changes (over v8)
---------------------
1. **Player pull.** Every team-season now also fetches the authoritative
   roster via GCClient.get_players() — person_id, first/last/full name,
   number, status, and handedness where GC has it. person_id is GC's own
   stable cross-team, cross-season identity, unlike the boxscore-inferred
   `roster` field (kept for backward compat) which only sees players who
   recorded a stat and has no stable id. Written to `_players.json`
   alongside the season file. Non-fatal: if the players endpoint fails, the
   game/boxscore/plays scrape still completes and a warning is printed.

2. **D2 raw/ partitioning.** Output no longer goes to a flat per-run
   timestamp folder. Each team-season now lands in
       raw/gamechanger/{season}/{team_slug}/{scrape_date}/
   with the season file, its stat sheet, `_players.json`, and a handedness
   coverage stub (`_handedness.yaml`) all together — snapshot-dated, never
   overwritten, per the warehouse plan's D2 decision. RAW_ROOT is
   env-overridable (GC_RAW_ROOT) so this can point at a shared location.

3. **Batch file as a CLI argument.** `python gc_scraper.py batch_2.txt` runs
   that specific batch file instead of the hardcoded batch.txt, so a large
   pull can be split into several files and run as separate sessions
   (useful for spacing a big harvest out, or resuming after a reboot).
   Falls back to batch.txt / interactive prompt when no argument is given.

Known raw-data quirks (found building bronze, 2026-08-12)
-----------------------------------------------------------
Two GC quirks surfaced while loading this scraper's output into DuckDB.
Nothing in v9 needed to change to fix these — they're notes for anyone
consuming the raw JSON directly, encoded once here rather than
re-discovered downstream:

1. **Per-game pitching IP uses baseball dot notation, not decimal.**
   `boxscore.<side>.pitching_players[].stats.IP` is `X.Y` where Y is
   OUTS (0, 1, or 2) — e.g. `1.1` = 1 inning + 1 out = 4 outs, NOT 1.1
   decimal innings. This is the same convention as `season_stats.pitching[].IP`.
   Confusingly, the sibling field one level up, `pitching_totals.IP` (the
   team's game total), uses a genuinely different convention: true decimal
   thirds (e.g. `5.666666666666667` = 5-and-2/3 innings). GC mixes both
   conventions in the same payload. Converting the per-player field with a
   decimal-thirds formula silently undercounts every fractional-inning
   outing — grounded against live GC data via the GameChanger MCP on
   Ayra Athletics' Paul S. (worst case: 12 outs undercounted across 24
   games pitched before the fix).

2. **A schedule-page game can show opponent="LIVE" with the real opponent
   name sitting in the `location` field instead** (e.g. `opponent: "LIVE"`,
   `location: "vs. Calvert Cutters 11U Hinton"`). This happens when Selenium
   scrapes a game that GC is actively broadcasting/live-scoring at the exact
   moment of the pull — the schedule page shows a "LIVE" badge in the slot
   where the opponent name normally goes, and the "vs. <team>" text that's
   normally the venue/location badge is what actually has the name. The box
   score and plays for that game can still be complete and correct even
   though these two display fields are wrong — check the actual stats before
   assuming the row is unusable. If a team is going to be rescraped anyway,
   the fix is trivial (just scrape again once the game is no longer live).
   If not — as with API Academy spring 2026, whose raw JSON was hand-patched
   for this on 2026-08-12 (see `manual_corrections` in that file's
   `metadata` and the matching audit note in `warehouse/bronze-walkthrough.md`)
   — the real opponent name and final score can usually be recovered from
   the location field and the box score's own run totals, no rescrape needed.

Everything else — Selenium schedule extraction, per-game boxscore/plays
fetch via the API, in-script cleaning and season-stat aggregation — is
unchanged from v8. Schedule scraping still uses Selenium because it is the
only source of human-readable date/opponent-name/venue metadata; GC's
game-summaries API (GCClient.list_games) can discover game_ids without a
browser but does not return those fields. That trade is unchanged in v9.

v8's note on auth still applies: the whole auth layer sits on two shared
modules, unchanged here:
  gc_client.py   — authenticated fetch, reads tokens.txt
  gc_harvest.py  — lifts a fresh token from a logged-in debug Chrome

Setup:
  1. Run launch_chrome_debug.bat, log in to web.gc.com in the window it opens.
  2. Run:  python gc_harvest.py --out tokens.txt   (writes/refreshes tokens.txt)
  3. Run:  python gc_scraper.py                    (single URL or batch.txt)
     or:   python gc_scraper.py batch_1.txt         (a specific batch file)
"""

import json
import time
import re
import sys
import random
import calendar
import traceback
from collections import defaultdict
from datetime import datetime, date
from pathlib import Path

# Shared auth core. Both live in the same folder as this script; make sure they
# are importable even if the scraper is launched from elsewhere.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from gc_client import GCClient, GCAuthError, GCError, GCNotFound, TokenPair  # noqa: E402
from handedness_overrides import apply_overrides_to_snapshot  # noqa: E402

try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

import os

SCRIPT_DIR   = Path(__file__).parent
TOKENS_FILE  = SCRIPT_DIR / "tokens.txt"
BATCH_FILE   = SCRIPT_DIR / "batch.txt"
# D2 snapshot-dated raw archive: raw/gamechanger/{season}/{team_slug}/{scrape_date}/
# Env-overridable so this can point at a shared/repo location later without
# code changes — mirrors gc_mcp_server.py's RAW_ROOT convention.
RAW_ROOT     = Path(os.environ.get("GC_RAW_ROOT", SCRIPT_DIR / "raw" / "gamechanger"))
# One cumulative, append-only log of everything the scraper couldn't fetch —
# a single known location (not per-team, not per-run) so a later Claude/MCP
# session can read it, look each entry up with gc_get_game / gc_get_games /
# gc_snapshot_team_api, and clear entries as they're resolved.
FAILURE_LOG  = RAW_ROOT / "_scrape_failures.txt"
SCHEDULE_WAIT_SECS  = 5

DELAY_WITHIN_GAME   = (0.75, 1.5)    # between boxscore and plays for one game
DELAY_BETWEEN_GAMES = (1.0, 3.0)     # between games in a schedule
DELAY_BETWEEN_TEAMS = (55.0, 90.0)   # between schedules in batch mode

SIZE_LIMIT_MB = 95


# ---------------------------------------------------------------------------
# Auth: token renewal via the browser harvester
# ---------------------------------------------------------------------------

def _harvest_refresh(creds) -> "TokenPair":
    """GCClient refresh hook — re-read a fresh token from the debug Chrome.

    Called automatically when the access token is within ~5 min of expiry, so
    a long batch never dies mid-scrape. Requires launch_chrome_debug.bat's
    Chrome to be open and logged in to web.gc.com. Raises GCAuthError (which
    aborts the scrape with a clear message) if the browser isn't reachable.
    """
    try:
        from gc_harvest import harvest_once
    except ImportError as exc:
        raise GCAuthError(f"gc_harvest.py not importable: {exc}")

    print("  token stale — harvesting a fresh one from the browser…")
    info = harvest_once(TOKENS_FILE, reload_tab=True)
    if not info:
        raise GCAuthError(
            "Harvest failed. Is the debug Chrome open and logged in to "
            "web.gc.com? Start it with launch_chrome_debug.bat."
        )
    return TokenPair(access=info["token"], refresh=None)


def build_client() -> GCClient:
    """One GCClient for the whole run, wired to harvest-on-stale."""
    return GCClient.from_tokens_file(
        TOKENS_FILE,
        refresh_fn=_harvest_refresh,
        allow_prompt=False,   # never block a scrape on stdin; harvest instead
    )


def jitter(low: float, high: float) -> None:
    time.sleep(random.uniform(low, high))


def log_failure(**fields) -> None:
    """Append one line to FAILURE_LOG — tab-separated, one failure per line.

    Cumulative across every run (append mode, never truncated), so a big
    harvest split across several batch-file sessions still lands everything
    in one place. Always includes `kind` ("game" or "team") plus whatever
    else the caller has on hand (team_id, season, schedule_url, game_id,
    date, opponent, error) — enough to hand a row straight to gc_get_game,
    gc_get_games, or gc_snapshot_team_api later without re-deriving anything.

    Best-effort: a logging failure must never take down the scrape itself.
    """
    try:
        FAILURE_LOG.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().isoformat(timespec="seconds")
        parts = [f"ts={ts}"] + [f"{k}={v}" for k, v in fields.items() if v not in (None, "")]
        with FAILURE_LOG.open("a", encoding="utf-8") as f:
            f.write("\t".join(parts) + "\n")
    except OSError as exc:
        print(f"  ! could not write to {FAILURE_LOG}: {exc}", file=sys.stderr)


# ---------------------------------------------------------------------------
# URL / descriptor helpers
# ---------------------------------------------------------------------------

def descriptor_from_url(url: str) -> str:
    """
    https://web.gc.com/teams/hYwpOHgPHCsF/2025-fall-bcc-big-train-11u/schedule
      → 2025-fall-bcc-big-train-11u
    """
    url = url.strip().rstrip("/")
    if url.endswith("/schedule"):
        url = url[: -len("/schedule")]
    segment = url.split("/")[-1]
    return re.sub(r"[^\w\-]", "_", segment) or "gamechanger"


def team_id_from_url(url: str) -> str:
    """Extract the GC team ID from a schedule URL (segment after /teams/)."""
    parts = url.strip().rstrip("/").split("/")
    try:
        return parts[parts.index("teams") + 1]
    except (ValueError, IndexError):
        return ""


def season_from_descriptor(descriptor: str) -> str:
    """'2026-spring-bcc-big-train-11u' → '2026-spring'"""
    parts = descriptor.split("-")
    if len(parts) >= 2 and parts[0].isdigit() and len(parts[0]) == 4:
        return f"{parts[0]}-{parts[1]}"
    return descriptor


def team_slug_from_descriptor(descriptor: str, season: str) -> str:
    """'2026-spring-bcc-big-train-11u', '2026-spring' → 'bcc-big-train-11u'

    Falls back to the full descriptor if the season prefix isn't present for
    some reason (season_from_descriptor returned the descriptor unchanged),
    so a D2 path is always producible.
    """
    prefix = f"{season}-"
    if descriptor.startswith(prefix):
        return descriptor[len(prefix):]
    return descriptor


# ---------------------------------------------------------------------------
# Schedule extraction via Selenium
# ---------------------------------------------------------------------------

# JavaScript injected into the loaded schedule page to pull structured data.
#
# Two extraction strategies run in sequence inside a single execute_script call:
#
# Strategy A (class-based): queries .ScheduleListByMonth__dayRow — works when
#   GC's React component names haven't changed and the page is hydrated.
#
# Strategy B (href-based): queries a[href*="/schedule/"] — works when class names
#   have been updated by GC; uses DOM parent traversal to find date text.
#   Falls through only if Strategy A produced zero results.
#
# JS regex patterns built from Python constants so their escape sequences never
# appear as static text in this file (avoids false-positive UNC-path scanner hits).
_JS_UUID_PAT = "/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$"
_JS_YEAR_PAT = r"\\b20\\d{2}\\b"
_JS_HA_PAT   = r"^(@|vs\\.)\\s*"

_SCHEDULE_JS = r"""
(function() {
    const MONTHS = {January:1,February:2,March:3,April:4,May:5,June:6,
                    July:7,August:8,September:9,October:10,November:11,December:12};
    const UUID_RE  = new RegExp("__JS_UUID_PAT__", "i");
    const YEAR_RE  = new RegExp("__JS_YEAR_PAT__");
    const results  = [];
    const seenIds  = {};

    // ── Strategy A: original class-based selectors ───────────────────────────
    document.querySelectorAll('.ScheduleListByMonth__dayRow').forEach(function(row) {
        const rowParts  = row.innerText.trim().split('\n');
        const dayOfWeek = rowParts[0] || '';
        const dayNum    = rowParts[1] || '';

        let section = row.parentElement;
        let monthEl = section ? section.previousElementSibling : null;
        while (monthEl && !YEAR_RE.test(monthEl.innerText || '')) {
            monthEl = monthEl.previousElementSibling;
        }
        const monthStr = monthEl ? monthEl.innerText.trim() : '';
        const mParts   = monthStr.split(' ');
        const monthNum = MONTHS[mParts[0]] || 0;
        const yearStr  = mParts[1] || '';
        const dateISO  = (monthNum && dayNum && yearStr)
            ? yearStr + '-' + String(monthNum).padStart(2,'0') + '-' + String(parseInt(dayNum,10)).padStart(2,'0')
            : monthStr;

        row.querySelectorAll('a.ScheduleListByMonth__event').forEach(function(link) {
            const m = link.href.match(UUID_RE);
            if (!m) return;
            const lines     = link.innerText.trim().split('\n');
            const firstLine = lines[0] || '';
            seenIds[m[1]]   = true;
            results.push({
                game_id:     m[1],
                date:        dateISO,
                day_of_week: dayOfWeek,
                home_away:   firstLine.startsWith('@') ? 'away' : 'home',
                opponent:    firstLine.replace(new RegExp("__JS_HA_PAT__", "i"), '').trim(),
                location:    (lines[1] || '').trim(),
                result:      (lines[2] || '').trim()
            });
        });
    });

    // ── Strategy B: href-based fallback (fires only if A returned nothing) ───
    // Used when GC has renamed their React component CSS classes.
    if (results.length === 0) {
        document.querySelectorAll('a[href*="/schedule/"]').forEach(function(link) {
            const m = link.href.match(UUID_RE);
            if (!m || seenIds[m[1]]) return;
            seenIds[m[1]] = true;

            const lines     = link.innerText.trim().split('\n');
            const firstLine = lines[0] || '';

            // Walk up the DOM (max 10 levels) looking for a container that has
            // both a month name and a 4-digit year — that is the date header.
            let dateISO  = '';
            let dayOfWeek = '';
            let el = link.parentElement;
            for (let depth = 0; depth < 10 && el; depth++) {
                const txt = el.innerText || '';
                if (YEAR_RE.test(txt)) {
                    const yearMatch = txt.match(new RegExp("__JS_YEAR_PAT__"));
                    const monMatch  = txt.match(
                        new RegExp('(January|February|March|April|May|June|July|' +
                                   'August|September|October|November|December)', 'i'));
                    const dayMatch  = txt.match(/\b([1-9]|[12]\d|3[01])\b/);
                    if (yearMatch && monMatch && dayMatch) {
                        const mon = MONTHS[monMatch[1]] || 0;
                        const yr  = yearMatch[0];
                        const day = parseInt(dayMatch[0], 10);
                        if (mon && yr && day) {
                            dateISO = yr + '-' + String(mon).padStart(2,'0') +
                                      '-' + String(day).padStart(2,'0');
                        }
                    }
                    break;
                }
                el = el.parentElement;
            }

            results.push({
                game_id:     m[1],
                date:        dateISO,
                day_of_week: dayOfWeek,
                home_away:   firstLine.startsWith('@') ? 'away' : 'home',
                opponent:    firstLine.replace(new RegExp("__JS_HA_PAT__", "i"), '').trim(),
                location:    (lines[1] || '').trim(),
                result:      (lines[2] || '').trim()
            });
        });
    }

    return results;
})();
""".replace("__JS_UUID_PAT__", _JS_UUID_PAT).replace("__JS_YEAR_PAT__", _JS_YEAR_PAT).replace("__JS_HA_PAT__", _JS_HA_PAT)

_TEAM_NAME_JS = r"""
(function() {
    const candidates = [
        document.querySelector('[class*="TeamHeader__name"]'),
        document.querySelector('[class*="TeamHeaderName"]'),
        document.querySelector('h1'),
    ];
    for (const el of candidates) {
        if (el) {
            const t = el.innerText.trim().split('\n')[0].trim();
            if (t && t.length > 1) return t;
        }
    }
    const main = document.querySelector('main');
    if (main) return main.innerText.trim().split('\n')[0].trim();
    return '';
})();
"""

# JS that recovers the CANONICAL descriptor from the page's own navigation links.
#
# A schedule URL may be given WITHOUT the descriptor segment — GC serves
# https://web.gc.com/teams/<id>/schedule perfectly happily, and that's what you
# get if you copy the address bar at the wrong moment. descriptor_from_url()
# then falls back to the team id, which cascades: season_from_descriptor() sees
# no leading year so it returns the id as the "season", and the snapshot lands
# in raw/gamechanger/<id>/<id>/<date>/ instead of <season>/<team-slug>/<date>/.
# Silent — the scrape itself succeeds, the data is fine, it's just filed
# somewhere build_bronze.py will happily load as a season named "Wf6dwfqL4Qe9".
#
# The page always renders its own nav links using the full descriptor
# (/teams/<id>/2026-fall-wild-bill-12u-hunter/schedule), so read GC's own
# string rather than trying to reconstruct one from the team name — GC's
# slug rules for punctuation are not obvious (parentheses are dropped, " - "
# becomes "---") and a near-miss would just create a second wrong folder.
_CANONICAL_DESCRIPTOR_JS = r"""
(function() {
    const parts = location.pathname.split('/').filter(Boolean);
    const idx = parts.indexOf('teams');
    if (idx === -1 || !parts[idx + 1]) return '';
    const teamId = parts[idx + 1];
    const skip = new Set(['schedule','team','stats','season-stats','roster','home','players']);
    const links = document.querySelectorAll('a[href*="/teams/' + teamId + '/"]');
    for (const a of links) {
        const seg = (a.getAttribute('href') || '').split('/').filter(Boolean);
        const j = seg.indexOf('teams');
        const cand = (j !== -1) ? seg[j + 2] : null;
        if (cand && !skip.has(cand) && /^\d{4}-/.test(cand)) return cand;
    }
    return '';
})();
"""

# JS that returns current CSS class names on schedule links — used for diagnostics
# when the primary JS selector fails, so we can see what GC renamed things to.
_DIAG_CLASSES_JS = r"""
(function() {
    const seen = {};
    const out  = [];
    document.querySelectorAll('a[href*="/schedule/"]').forEach(function(link) {
        let el = link;
        for (let i = 0; i < 6 && el; i++) {
            (el.className || '').split(/\s+/).forEach(function(cls) {
                if (cls && !seen[cls]) { seen[cls] = true; out.push(cls); }
            });
            el = el.parentElement;
        }
    });
    return out;
})();
"""


UUID_RE = re.compile(
    r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',
    re.IGNORECASE,
)
_SCHED_LINK_RE = re.compile(
    r'href="[^"]*?/schedule/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"[^>]*?>'
    r'(.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)
_TAG_RE       = re.compile(r'<[^>]+>')
_NBSP_RE      = re.compile(r'&[a-z]+;|&#\d+;')
_BLOCK_TAG_RE = re.compile(r'<(?:div|span|p|li|br)[^>]*>', re.IGNORECASE)
_RESULT_RE    = re.compile(r'(?:(?<=\s)|^)([WLT])\s+(\d+)-(\d+)\s*$')
# Parses a game-level result string like "W 13-3", "L 1-15", "T 4-4".
_GAME_RESULT_RE = re.compile(r'^([WLTwlt])\s+(\d+)\s*-\s*(\d+)')

# HTML date-extraction helpers (used by _games_from_html fallback)
_MONTH_NAMES_MAP = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
}
_MONTH_HDR_RE   = re.compile(
    r'(January|February|March|April|May|June|July|August|September|'
    r'October|November|December)\s+(20\d{2})',
    re.IGNORECASE,
)
# Primary dayRow class name — used when GC's original class names are present.
# A proximity fallback (below) kicks in when this pattern finds nothing.
_DAY_ROW_RE        = re.compile(r'ScheduleListByMonth__dayRow', re.IGNORECASE)
_GAME_LINK_UUID_RE = re.compile(
    r'/schedule/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})',
    re.IGNORECASE,
)


def _strip_html(s: str) -> str:
    s = _BLOCK_TAG_RE.sub('\n', s)
    s = _NBSP_RE.sub(' ', _TAG_RE.sub('', s))
    return s.strip()


def _extract_date_map_from_html(html: str) -> dict[str, tuple[str, str]]:
    """
    Scan the SSR schedule HTML and build {game_id: (date_iso, day_of_week)}.

    Primary strategy (class-based):
      1. Collect all month-year header positions.
      2. Split at every ScheduleListByMonth__dayRow boundary.
      3. Per chunk: find nearest preceding month header + first day number.
      4. Map every game UUID in that chunk to the resulting ISO date.

    Fallback strategy (proximity-based — fires when no dayRow class found):
      For each schedule link UUID, look at the 400 chars of HTML immediately
      preceding it. Extract the last day-like number and the nearest preceding
      month header to build an ISO date. This is class-name-agnostic and
      survives GC renaming their React components.
    """
    date_map: dict[str, tuple[str, str]] = {}

    # ── Step 1: collect (char_pos, month_num, year) for every month header ──
    month_headers: list[tuple[int, int, int]] = []
    for m in _MONTH_HDR_RE.finditer(html):
        mnum = _MONTH_NAMES_MAP.get(m.group(1).lower(), 0)
        year = int(m.group(2))
        if mnum:
            month_headers.append((m.start(), mnum, year))

    if not month_headers:
        return date_map

    def _nearest_month(pos: int) -> tuple[int, int]:
        """Return (month_num, year) of the latest header at or before pos."""
        best = (0, 0)
        for hpos, mnum, year in month_headers:
            if hpos <= pos:
                best = (mnum, year)
            else:
                break
        return best

    # ── Step 2: locate every dayRow boundary ────────────────────────────────
    row_starts = [m.start() for m in _DAY_ROW_RE.finditer(html)]

    if row_starts:
        # ── Primary strategy (class-based) ──────────────────────────────────
        for i, start in enumerate(row_starts):
            end   = row_starts[i + 1] if i + 1 < len(row_starts) else len(html)
            chunk = html[start:end]

            mnum, year = _nearest_month(start)
            if not (mnum and year):
                continue

            plain = _NBSP_RE.sub(' ', _TAG_RE.sub(' ', chunk[:300]))
            day_matches = re.findall(r'\b([1-9]|[12]\d|3[01])\b', plain)
            if not day_matches:
                continue

            day_num = int(day_matches[0])
            try:
                dt       = datetime(year, mnum, day_num)
                date_iso = dt.strftime("%Y-%m-%d")
                dow      = dt.strftime("%A")
            except ValueError:
                continue

            for um in _GAME_LINK_UUID_RE.finditer(chunk):
                gid = um.group(1).lower()
                if gid not in date_map:
                    date_map[gid] = (date_iso, dow)

    else:
        # ── Fallback strategy: proximity-based, class-name-agnostic ─────────
        # GC may have renamed ScheduleListByMonth__dayRow; instead we look at
        # the raw HTML just before each schedule link and pick the last
        # plausible day number that falls within a valid calendar date for
        # the nearest preceding month header.
        for um in _GAME_LINK_UUID_RE.finditer(html):
            gid = um.group(1).lower()
            if gid in date_map:
                continue
            pos        = um.start()
            mnum, year = _nearest_month(pos)
            if not (mnum and year):
                continue

            # Look at up to 400 chars before this link for a day number.
            preceding = html[max(0, pos - 400):pos]
            plain     = _NBSP_RE.sub(' ', _TAG_RE.sub(' ', preceding))
            # Take the LAST plausible day number (closest to the link).
            day_matches = re.findall(r'\b([1-9]|[12]\d|3[01])\b', plain)
            if not day_matches:
                continue

            _, max_day = calendar.monthrange(year, mnum)
            for candidate in reversed(day_matches):
                day_num = int(candidate)
                if 1 <= day_num <= max_day:
                    try:
                        dt       = datetime(year, mnum, day_num)
                        date_map[gid] = (dt.strftime("%Y-%m-%d"), dt.strftime("%A"))
                    except ValueError:
                        pass
                    break

    return date_map


def _parse_link_text(raw: str) -> tuple[str, str, str, str]:
    """
    Parse the stripped text of a schedule game link into (home_away, opponent, location, result).
    """
    text = raw.strip()

    rm = _RESULT_RE.search(text)
    if rm:
        game_res = rm.group(0).strip()
        text = text[: rm.start()].strip()
    else:
        game_res = ""

    ha_m = re.match(r'^(@|vs\.)\s*', text, re.IGNORECASE)
    if ha_m:
        home_away = "away" if ha_m.group(1) == "@" else "home"
        text = text[ha_m.end():]
    else:
        home_away = "home"

    if "\n" in text:
        parts    = [p.strip() for p in text.split("\n") if p.strip()]
        opponent = parts[0] if parts else text
        location = parts[1] if len(parts) > 1 else ""
    else:
        nl_m = re.search(r'No location', text, re.IGNORECASE)
        if nl_m:
            opponent = text[: nl_m.start()].strip()
            location = "No location"
        else:
            opponent = text.strip()
            location = ""

    return home_away, opponent, location, game_res


def _games_from_html(html: str) -> list[dict]:
    """
    Fallback: extract game IDs (+ best-effort metadata) by parsing the SSR HTML.
    """
    date_map = _extract_date_map_from_html(html)

    seen:   set[str]  = set()
    result: list[dict] = []

    for m in _SCHED_LINK_RE.finditer(html):
        gid  = m.group(1).lower()
        if gid in seen:
            continue
        seen.add(gid)

        raw_text  = _strip_html(m.group(2))
        home_away, opponent, location, game_res = _parse_link_text(raw_text)

        date_iso, dow = date_map.get(gid, ("NA", "NA"))

        result.append({
            "game_id":     gid,
            "date":        date_iso,
            "day_of_week": dow,
            "home_away":   home_away,
            "opponent":    opponent,
            "location":    location or "NA",
            "result":      game_res,
        })

    if not result:
        GAME_CONTEXT_TERMS = {"game", "boxscore", "plays", "schedule", "match"}
        for m in UUID_RE.finditer(html):
            gid = m.group().lower()
            if gid in seen:
                continue
            start = max(0, m.start() - 150)
            end   = min(len(html), m.end() + 150)
            ctx   = html[start:end].lower()
            if any(t in ctx for t in GAME_CONTEXT_TERMS):
                seen.add(gid)
                date_iso, dow = date_map.get(gid, ("NA", "NA"))
                result.append({
                    "game_id": gid, "date": date_iso, "day_of_week": dow,
                    "home_away": "", "opponent": "", "location": "NA", "result": "",
                })

    return result


def extract_schedule_data(schedule_url: str) -> tuple[str, list[dict], str]:
    """
    Load schedule page with Selenium and extract team name + ordered game list.

    The page is given SCHEDULE_WAIT_SECS to render before anything is read —
    the game links the HTML parser needs are script-injected after load and are
    absent from page_source until then.

    Strategy (against the rendered page_source):
      1. _games_from_html() — HTML regex over the rendered DOM; class-name-
         agnostic, with a proximity-based date fallback. Primary because it
         survives GC renaming their React component CSS classes and works even
         when the class-based DOM never fully hydrates.
      2. execute_script(_SCHEDULE_JS) — JS extraction; only attempted if HTML
         returns nothing.
           A. Class-based (.ScheduleListByMonth__dayRow) — original GC component names.
           B. href-based (a[href*="/schedule/"]) — fires when A returns nothing;
              survives GC renaming their CSS classes.

    Returns (team_name, games_meta_list, canonical_descriptor).
    canonical_descriptor is GC's own "2026-fall-wild-bill-12u-hunter"
    string read off the page's nav links, or "" if not found. The
    caller needs it when the supplied URL omitted that segment.
    """
    if not SELENIUM_AVAILABLE:
        sys.exit(
            "\n❌  Selenium is required.\n"
            "Install with: pip install selenium\n"
        )

    print(f"\n  Loading schedule: {schedule_url}")
    print(f"  Waiting {SCHEDULE_WAIT_SECS}s for page to render…")

    options = ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    try:
        driver = webdriver.Chrome(options=options)
        driver.get(schedule_url)
        # The schedule content (and the game links the HTML parser relies on) is
        # injected by the page's own scripts after load, so it only appears in
        # page_source once the render delay has elapsed — wait before capturing.
        time.sleep(SCHEDULE_WAIT_SECS)
        html = driver.page_source

        games_meta: list[dict] = []
        team_name: str = ""
        canonical_descriptor: str = ""

        # ── Strategy 1: HTML parsing of the rendered DOM (primary) ────────────
        # Class-name-agnostic; survives GC renaming their React components and
        # works even when the page never fully hydrates the class-based DOM.
        games_meta = _games_from_html(html)
        if games_meta:
            has_dates = any(g.get("date") not in ("", "NA") for g in games_meta)
            if has_dates:
                print("  ✓ HTML extraction succeeded")
            else:
                print("  ⚠️  HTML extraction: games found but no dates — month headers may be missing from SSR")
        else:
            # ── Strategy 2: JS extraction (fallback) ──────────────────────────
            # Class-based / href-based DOM queries; needs the React component
            # tree to be hydrated.
            print("  ℹ️  HTML extraction empty — trying JS extraction…")
            js_strategy = "none"
            try:
                js_result = driver.execute_script(_SCHEDULE_JS)
                if js_result:
                    games_meta  = js_result
                    has_dates   = any(g.get("date") for g in js_result)
                    js_strategy = "A (class-based)" if has_dates else "B (href-based)"
                    print(f"  ✓ JS extraction succeeded — strategy {js_strategy}")
                else:
                    try:
                        live_classes = driver.execute_script(_DIAG_CLASSES_JS) or []
                        sched_cls    = sorted(set(
                            c for c in live_classes
                            if any(kw in c.lower() for kw in
                                   ("schedule", "event", "game", "day", "month", "list"))
                        ))
                        if sched_cls:
                            print(f"  ℹ️  JS empty — schedule-related classes in DOM: {sched_cls[:15]}")
                        else:
                            print("  ℹ️  JS empty — no schedule-related classes found (page may not be hydrated)")
                    except Exception:
                        pass
            except Exception:
                pass

        try:
            team_name = driver.execute_script(_TEAM_NAME_JS) or ""
        except Exception:
            pass

        try:
            canonical_descriptor = driver.execute_script(_CANONICAL_DESCRIPTOR_JS) or ""
        except Exception:
            pass

        driver.quit()
    except Exception as exc:
        print(f"  ❌  Selenium error: {exc}")
        return "", [], ""

    if not games_meta:
        print("  ⚠️  Both HTML and JS extraction returned nothing")

    if not team_name:
        m = re.search(r'<title[^>]*>([^<|]+)', html, re.IGNORECASE)
        if m:
            team_name = m.group(1).strip()

    for g in games_meta:
        d = g.get("date") or ""
        if re.match(r'\d{4}-\d{2}-\d{2}$', d):
            try:
                g["day_of_week"] = datetime.strptime(d, "%Y-%m-%d").strftime("%A")
            except ValueError:
                pass
        if not g.get("date"):
            g["date"] = "NA"
        if not g.get("day_of_week"):
            g["day_of_week"] = "NA"
        if not g.get("location"):
            g["location"] = "NA"

    print(f"  ✓ Team: {team_name or '(unknown)'}  |  Found {len(games_meta)} game(s)")
    return team_name, games_meta, canonical_descriptor


# ---------------------------------------------------------------------------
# Post-processor helpers
# ---------------------------------------------------------------------------

UUID_TMPL_RE = re.compile(
    r'\$\{([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\}',
    re.IGNORECASE,
)


def _build_player_lookup(plays: dict) -> dict[str, dict]:
    lookup = {}
    for team_id, players in (plays.get("team_players") or {}).items():
        for p in (players or []):
            pid = p.get("id", "")
            if pid:
                name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
                lookup[pid] = {
                    "name":    name or pid[:8],
                    "number":  p.get("number", ""),
                    "team_id": team_id,
                }
    return lookup


def _resolve_template(template: str, lookup: dict[str, dict]) -> str:
    return UUID_TMPL_RE.sub(
        lambda m: lookup.get(m.group(1), {}).get("name", f"?{m.group(1)[:8]}"),
        template,
    )


def _template_of(obj) -> str:
    """Extract the template string from a GC detail item.

    GC's API is inconsistent: a detail (name_template, an at_plate/final/message
    entry) may arrive as a dict {"template": "..."} or as a bare string. Both
    shapes appear in the wild — e.g. the Stars team's `messages` are plain
    strings while every other team's are dicts. Normalize to a string here so
    callers never have to guess.
    """
    if isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return obj.get("template", "") or ""
    return ""


def _resolve_detail_list(items: list, lookup: dict[str, dict]) -> list[str]:
    result = []
    for item in (items or []):
        template = _template_of(item)
        if template:
            result.append(_resolve_template(template, lookup))
    return result


def _ip_to_thirds(ip) -> int:
    s = str(ip).strip()
    if "." in s:
        whole, frac = s.split(".", 1)
        return int(whole) * 3 + int(frac[0])
    return int(s) * 3


def _thirds_to_ip(thirds: int) -> str:
    return f"{thirds // 3}.{thirds % 3}"


# ---------------------------------------------------------------------------
# Boxscore cleaning / normalization
# ---------------------------------------------------------------------------
#
# A game's "boxscore" can be in one of two shapes:
#   • cleaned  → {"us": {...lineup_totals/players/extra...}, "opponent": {...}}
#   • raw      → {<team_id>: {"players": [...], "groups": [...]}, ...}
#
# Older script versions sometimes saved the raw shape (e.g. when the per-game
# post-processor errored and fell back to storing the untouched API response).
# build_season_stats only understands the cleaned shape, so any raw game was
# silently skipped — producing phantom 0-0 ties and missing player stats.
#
# clean_boxscore_team + normalize_boxscore let us read either shape so season
# aggregation is correct regardless of how a game was stored.

def clean_boxscore_team(raw_team: dict, lookup: dict[str, dict]) -> dict:
    """Convert one raw team boxscore ({players, groups}) into the cleaned shape
    ({lineup_totals, lineup_players, lineup_extra, pitching_totals, ...})."""
    out: dict = {}
    for group in (raw_team.get("groups") or []):
        cat = group.get("category", "unknown")
        out[f"{cat}_totals"] = group.get("team_stats", {})

        player_rows = []
        for row in (group.get("stats") or []):
            pid   = row.get("player_id", "")
            info  = lookup.get(pid, {})
            stats = dict(row.get("stats") or {})
            if "IP" in stats and isinstance(stats["IP"], float):
                full   = int(stats["IP"])
                thirds = round((stats["IP"] - full) * 3)
                stats["IP"] = f"{full}.{thirds}"
            player_rows.append({
                "name":      info.get("name", pid[:8]),
                "number":    info.get("number", ""),
                "positions": row.get("player_text", ""),
                "stats":     stats,
            })
        out[f"{cat}_players"] = player_rows

        extra_out = {}
        for extra in (group.get("extra") or []):
            stat_name = extra.get("stat_name", "?")
            extra_out[stat_name] = [
                {
                    "name":   lookup.get(s.get("player_id", ""), {}).get("name", "?"),
                    "number": lookup.get(s.get("player_id", ""), {}).get("number", ""),
                    "value":  s.get("value"),
                }
                for s in (extra.get("stats") or [])
            ]
        if extra_out:
            out[f"{cat}_extra"] = extra_out
    return out


def normalize_boxscore(game: dict, our_team_id: str | None) -> dict:
    """Return a game's boxscore in cleaned {us, opponent} form, whatever its
    stored shape. Empty boxscores return {}."""
    bs = game.get("boxscore") or {}
    if not bs:
        return {}
    # Already cleaned?
    if any(k in ("us", "opponent") for k in bs.keys()):
        return bs
    # Raw shape — clean each team using player names from this game's plays.
    lookup = _build_player_lookup(game.get("plays") or {})
    out: dict = {}
    for tid, raw in bs.items():
        label = "us" if tid == our_team_id else "opponent"
        out[label] = clean_boxscore_team(raw, lookup)
    return out


# ---------------------------------------------------------------------------
# Roster builders
# ---------------------------------------------------------------------------

def build_roster(raw_games: list, our_team_id: str) -> list[dict]:
    """Boxscore-inferred roster (v8 behaviour, kept for backward compat).

    Only sees players who appear in at least one game's plays, and has no
    stable cross-season id. See fetch_authoritative_players() for the new
    person_id-bearing roster added in v9.
    """
    players: dict[str, dict] = {}
    for game in raw_games:
        tp = (game.get("plays") or {}).get("team_players") or {}
        for p in (tp.get(our_team_id) or []):
            pid = p.get("id", "")
            if not pid or pid in players:
                continue
            name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
            players[pid] = {
                "id":     pid,
                "name":   name or pid[:8],
                "number": p.get("number", ""),
            }

    def sort_key(p):
        n = p.get("number", "") or ""
        return (n.zfill(4) if n.isdigit() else "zzzz" + n, p["name"])

    return sorted(players.values(), key=sort_key)


def fetch_authoritative_players(client: GCClient, team_id: str) -> tuple[list[dict], dict]:
    """v9: pull the authoritative roster (person_id, handedness where known).

    Non-fatal by design — called from run_schedule() inside a try/except.
    Returns (flattened_players, handedness_coverage). Empty list + empty dict
    on failure; the caller logs a warning and continues, since this must never
    abort a scrape that's otherwise working.

    Two sources, because neither alone is enough (see gc_client's "public
    roster path" notes):

      - the MANAGER endpoint (/teams/{uuid}/players) carries `person_id`,
        GC's stable cross-team/cross-season identity, which is the right key
        for dim_player — but it 403s for every team the account doesn't
        manage, i.e. ~all of them.
      - the PUBLIC endpoint (/teams/public/{public_id}/players + per-player
        profile) works for ANY team and is the only source of handedness,
        but its ids are per-team-membership, not cross-season.

    So: try the manager path, always do the public path, merge on name. For
    your own teams you get both; for everyone else's you get the public half,
    which is what actually fills _handedness.yaml.
    """
    players: list[dict] = []
    try:
        players = client.flatten_players(client.get_players(team_id))
    except Exception as exc:
        print(f"    (manager roster unavailable — {type(exc).__name__}; public path only)")

    public = client.public_roster_handedness(team_id)

    # Merge handedness onto the manager rows where we have both.
    if players and public:
        by_name = {p["full_name"].lower(): p for p in public if p.get("full_name")}
        for p in players:
            match = by_name.get((p.get("full_name") or "").lower())
            if match and not p.get("has_handedness"):
                p["bat"], p["throw"] = match["bat"], match["throw"]
                p["has_handedness"] = match["has_handedness"]
            if match:
                p["player_uuid"] = match.get("player_uuid")

    roster = players or public
    coverage = client.handedness_coverage(roster) if roster else {}
    if roster:
        # Overwrite the stub with the uuid-carrying format the 83 existing
        # files already use, so bronze parses exactly one shape.
        coverage["yaml_fragment"] = client.handedness_yaml(
            players if players else public
        )
    return roster, coverage


# ---------------------------------------------------------------------------
# Per-game post-processor
# ---------------------------------------------------------------------------

def postprocess_game(game: dict, our_team_id: str, schedule_meta: dict) -> dict:
    plays_raw = game.get("plays") or {}
    lookup    = _build_player_lookup(plays_raw)
    bs_raw    = game.get("boxscore") or {}

    def label(team_id: str) -> str:
        return "us" if team_id == our_team_id else "opponent"

    cleaned_bs = {label(tid): clean_boxscore_team(raw, lookup) for tid, raw in bs_raw.items()}

    cleaned_plays = []
    for play in (plays_raw.get("plays") or []):
        cleaned_plays.append({
            "order":         play.get("order"),
            "inning":        play.get("inning"),
            "half":          play.get("half"),
            "outcome":       _template_of(play.get("name_template")),
            "outs":          play.get("outs"),
            "outs_changed":  play.get("did_outs_change"),
            "home_score":    play.get("home_score"),
            "away_score":    play.get("away_score"),
            "score_changed": play.get("did_score_change"),
            "at_plate":      _resolve_detail_list(play.get("at_plate_details"), lookup),
            "result":        _resolve_detail_list(play.get("final_details"),    lookup),
            "messages":      _resolve_detail_list(play.get("messages"),          lookup),
        })

    return {
        "game_id":    game.get("game_id"),
        "scraped_at": game.get("scraped_at"),
        "date":        schedule_meta.get("date")        or "NA",
        "day_of_week": schedule_meta.get("day_of_week") or "NA",
        "home_away":   schedule_meta.get("home_away",   ""),
        "opponent":    schedule_meta.get("opponent",    ""),
        "location":    schedule_meta.get("location")    or "NA",
        "result":      schedule_meta.get("result",      ""),
        "boxscore":   cleaned_bs,
        "plays": {
            "sport": plays_raw.get("sport", "baseball"),
            "plays": cleaned_plays,
        },
    }


# ---------------------------------------------------------------------------
# Team ID detection
# ---------------------------------------------------------------------------

def _detect_our_team_id(raw_games: list) -> str | None:
    candidate_sets = [
        set((g.get("boxscore") or {}).keys())
        for g in raw_games
        if g.get("boxscore")
    ]
    if not candidate_sets:
        return None
    common = candidate_sets[0].intersection(*candidate_sets[1:])
    if not common:
        return None
    return min(common, key=lambda k: (len(k), k))


# ---------------------------------------------------------------------------
# Season stat sheet
# ---------------------------------------------------------------------------

def _aggregate_extra(extra_section: dict) -> dict:
    """Collapse a boxscore '*_extra' section ({stat: [{name, value}, ...]}) into
    {player_name: {stat: summed_value}}."""
    out: dict = defaultdict(dict)
    for stat, entries in (extra_section or {}).items():
        for entry in entries:
            nm = entry.get("name", "")
            if nm:
                out[nm][stat] = out[nm].get(stat, 0) + (entry.get("value") or 0)
    return out


def build_season_stats(cleaned_games: list, our_team_id: str | None = None) -> dict:
    wins = losses = ties = runs_scored = runs_allowed = 0
    batting   = defaultdict(lambda: defaultdict(int))
    pitching  = defaultdict(lambda: {"thirds": 0, "H": 0, "R": 0, "ER": 0,
                                     "BB": 0, "SO": 0, "#P": 0, "BF": 0,
                                     "HBP": 0, "WP": 0})
    player_number: dict[str, str] = {}

    for g in cleaned_games:
        # Accept either cleaned ({us,opponent}) or raw ({team_id:{...}}) boxscores.
        bs  = normalize_boxscore(g, our_team_id)
        us  = bs.get("us",       {})
        opp = bs.get("opponent", {})

        # ── Determine the game's runs/result ────────────────────────────────
        # Prefer the schedule "result" string (e.g. "W 13-3", "L 1-15"), which
        # is present even when GameChanger has no box-score data for the game.
        # Fall back to box-score lineup totals only when no result string.
        our_r = opp_r = None
        decided = None  # 'W' / 'L' / 'T'
        rm = _GAME_RESULT_RE.match((g.get("result") or "").strip())
        if rm:
            decided = rm.group(1).upper()
            our_r   = int(rm.group(2))
            opp_r   = int(rm.group(3))
        elif us.get("lineup_totals") or opp.get("lineup_totals"):
            our_r = us.get("lineup_totals",  {}).get("R", 0) or 0
            opp_r = opp.get("lineup_totals", {}).get("R", 0) or 0
            decided = "W" if our_r > opp_r else "L" if our_r < opp_r else "T"

        if decided is None:
            # No result string and no box score — game not played/scored; skip.
            continue

        runs_scored  += our_r
        runs_allowed += opp_r
        if   decided == "W": wins   += 1
        elif decided == "L": losses += 1
        else:                ties   += 1

        extra_by_player = _aggregate_extra(us.get("lineup_extra"))

        for p in (us.get("lineup_players") or []):
            nm = p["name"]
            player_number[nm] = p.get("number", "")
            s = p.get("stats", {})
            b = batting[nm]
            b["G"] += 1
            for st in ("AB", "R", "H", "RBI", "BB", "SO"):
                b[st] += s.get(st, 0) or 0
            for st in ("2B", "3B", "HR", "SB", "CS", "HBP", "SHF", "TB", "E"):
                b[st] += extra_by_player[nm].get(st, 0)

        p_extra_by_player = _aggregate_extra(us.get("pitching_extra"))

        for p in (us.get("pitching_players") or []):
            nm = p["name"]
            player_number[nm] = p.get("number", "")
            s  = p.get("stats", {})
            pd = pitching[nm]
            pd["thirds"] += _ip_to_thirds(s.get("IP", 0))
            for st in ("H", "R", "ER", "BB", "SO"):
                pd[st] += s.get(st, 0) or 0
            for st in ("#P", "BF", "HBP", "WP"):
                pd[st] += p_extra_by_player[nm].get(st, 0)

    batting_rows = []
    for nm, b in sorted(batting.items()):
        ab  = b["AB"]
        h   = b["H"]
        tb  = b["TB"] if b["TB"] else (h + b["2B"] + 2*b["3B"] + 3*b["HR"])
        avg = round(h / ab, 3) if ab > 0 else 0.0
        obp_num = h + b["BB"] + b["HBP"]
        obp_den = ab + b["BB"] + b["HBP"] + b["SHF"]
        obp = round(obp_num / obp_den, 3) if obp_den > 0 else 0.0
        slg = round(tb / ab, 3) if ab > 0 else 0.0
        batting_rows.append({
            "name": nm, "number": player_number.get(nm, ""),
            "G": b["G"], "AB": b["AB"], "R": b["R"], "H": b["H"],
            "2B": b["2B"], "3B": b["3B"], "HR": b["HR"], "RBI": b["RBI"],
            "BB": b["BB"], "SO": b["SO"], "SB": b["SB"], "CS": b["CS"],
            "HBP": b["HBP"], "E": b["E"],
            "AVG": f"{avg:.3f}", "OBP": f"{obp:.3f}",
            "SLG": f"{slg:.3f}", "OPS": f"{round(obp+slg, 3):.3f}",
        })
    batting_rows.sort(key=lambda r: (-r["AB"], r["name"]))

    pitching_rows = []
    for nm, pd in sorted(pitching.items()):
        thirds = pd["thirds"]
        ip_dec = thirds / 3
        era  = round((pd["ER"] * 3 * 7) / thirds, 2) if thirds > 0 else 0.0
        whip = round((pd["BB"] + pd["H"]) / ip_dec, 2) if ip_dec > 0 else 0.0
        k9   = round((pd["SO"] * 27) / thirds, 1)     if thirds > 0 else 0.0
        pitching_rows.append({
            "name": nm, "number": player_number.get(nm, ""),
            "IP": _thirds_to_ip(thirds),
            "H": pd["H"], "R": pd["R"], "ER": pd["ER"],
            "BB": pd["BB"], "SO": pd["SO"], "#P": pd["#P"],
            "BF": pd["BF"], "HBP": pd["HBP"], "WP": pd["WP"],
            "ERA": f"{era:.2f}", "WHIP": f"{whip:.2f}", "K/9": f"{k9:.1f}",
        })
    pitching_rows.sort(key=lambda r: (-_ip_to_thirds(r["IP"]), r["name"]))

    return {
        "record": {
            "W": wins, "L": losses, "T": ties,
            "R": runs_scored, "RA": runs_allowed,
            "games": wins + losses + ties,
        },
        "batting":  batting_rows,
        "pitching": pitching_rows,
    }


def format_season_report(descriptor: str, stats: dict) -> str:
    sep = "=" * 100
    rec = stats["record"]
    n   = rec["games"]
    win_pct = rec["W"] / n if n else 0
    desc = descriptor.upper().replace("-", " ")

    lines = [
        sep,
        f"  SEASON STAT SHEET  —  {desc}",
        sep,
        f"  Record: {rec['W']}-{rec['L']}"
        + (f"-{rec['T']}" if rec["T"] else "")
        + f"  ({win_pct:.3f})    "
        + f"Runs Scored: {rec['R']}    Runs Allowed: {rec['RA']}    "
        + f"Run Diff: {rec['R']-rec['RA']:+d}    Games: {n}",
        sep, "",
        "  BATTING", "",
    ]

    bh = ("  {:<20s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} "
          "{:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s}  {:>5s} {:>5s} {:>5s} {:>5s}")
    bf = ("  {:<20s} {:>3} {:>3} {:>3} {:>3} {:>3} {:>3} {:>3} "
          "{:>3} {:>3} {:>3} {:>3} {:>3} {:>3}  {:>5s} {:>5s} {:>5s} {:>5s}")
    hdr = bh.format("NAME", "#", "G", "AB", "R", "H", "2B", "3B",
                    "HR", "RBI", "BB", "SO", "SB", "HBP", "AVG", "OBP", "SLG", "OPS")
    lines += [hdr, "  " + "-" * (len(hdr) - 2)]
    for r in stats["batting"]:
        lines.append(bf.format(
            r["name"], r["number"], r["G"], r["AB"], r["R"], r["H"],
            r["2B"], r["3B"], r["HR"], r["RBI"], r["BB"], r["SO"],
            r["SB"], r["HBP"], r["AVG"], r["OBP"], r["SLG"], r["OPS"]))

    lines += ["", "  PITCHING", ""]
    ph = ("  {:<20s} {:>3s} {:>5s} {:>4s} {:>4s} {:>4s} {:>4s} {:>4s} "
          "{:>4s} {:>5s} {:>5s} {:>5s}")
    pf = ("  {:<20s} {:>3} {:>5s} {:>4} {:>4} {:>4} {:>4} {:>4} "
          "{:>4} {:>5s} {:>5s} {:>5s}")
    phdr = ph.format("NAME", "#", "IP", "H", "R", "ER", "BB", "SO",
                     "#P", "ERA", "WHIP", "K/9")
    lines += [phdr, "  " + "-" * (len(phdr) - 2)]
    for r in stats["pitching"]:
        lines.append(pf.format(
            r["name"], r["number"], r["IP"], r["H"], r["R"], r["ER"],
            r["BB"], r["SO"], r["#P"], r["ERA"], r["WHIP"], r["K/9"]))

    lines += ["", sep]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Per-schedule runner
# ---------------------------------------------------------------------------

def run_schedule(schedule_url: str, client: GCClient) -> dict | None:
    """Scrape one team-season and write it into the D2 raw/ snapshot archive.

    Output directory is computed per-schedule (not once for the whole batch),
    since each team-season can belong to a different season/team_slug:
        raw/gamechanger/{season}/{team_slug}/{scrape_date}/
    """
    descriptor = descriptor_from_url(schedule_url)
    team_id    = team_id_from_url(schedule_url)
    season     = season_from_descriptor(descriptor)
    team_slug  = team_slug_from_descriptor(descriptor, season)

    print(f"\n{'='*70}")
    print(f"Schedule: {descriptor}")
    print(f"URL: {schedule_url}")
    print(f"{'='*70}")

    team_name, games_meta, canonical_descriptor = extract_schedule_data(schedule_url)
    if not games_meta:
        print("  ⚠️  No games found on schedule page — skipping.")
        return None

    # The rendered-page team name is unreliable — _TEAM_NAME_JS's selectors are
    # class-name based and went stale, so it returns "" and the <title>
    # fallback quietly wrote team_name="GameChanger App" into every raw file
    # before 2026-09-06. Prefer GC's own API field, which can't rot that way,
    # and keep whatever the page produced only as a fallback.
    try:
        api_name = client.team_name_from_meta(client.get_public_team(team_id))
        if api_name:
            if team_name and team_name != api_name:
                print(f"  ℹ️  Team name from API: {api_name!r} "
                      f"(page said {team_name!r})")
            team_name = api_name
    except Exception as exc:
        print(f"  ⚠️  Could not fetch team name from API ({type(exc).__name__}) — "
              f"falling back to page value {team_name!r}")

    # If the URL carried no descriptor segment, descriptor_from_url() fell back
    # to the bare team id and every path derived from it is wrong (see the
    # _CANONICAL_DESCRIPTOR_JS notes). Recover GC's own descriptor from the
    # rendered page and redo the derivation before anything gets written.
    if descriptor == team_id and canonical_descriptor:
        descriptor = canonical_descriptor
        season     = season_from_descriptor(descriptor)
        team_slug  = team_slug_from_descriptor(descriptor, season)
        print(f"  ℹ️  URL had no descriptor segment — recovered from page: {descriptor}")
        print(f"      filing under {season}/{team_slug}/")
    elif descriptor == team_id:
        # Refuse rather than file it under a folder named after the team id.
        print(f"  ❌  URL has no descriptor segment and it could not be recovered "
              f"from the page.\n"
              f"      Use the full URL, e.g. "
              f".../teams/{team_id}/2026-fall-team-name-12u/schedule\n"
              f"      Skipping so this doesn't land in raw/gamechanger/{team_id}/.")
        log_failure(kind="missing_descriptor", team_id=team_id,
                    schedule_url=schedule_url, error="no descriptor segment in URL")
        return None

    # ── v9: cross-check Selenium's schedule-page links against GC's API ────
    # Root cause of the crash this was added for: the schedule page renders
    # a clickable link for entries that never became a real game object in
    # GC's backend — a TBD/rescheduled slot, a canceled game, a doubleheader
    # placeholder. Confirmed against gc_get_games (game-summaries, the
    # authoritative source) for 7 teams: every 404'd game_id from that run
    # was simply absent from the API's completed-games list, and one was
    # even still labeled opponent="TBD" on the schedule page itself. Filter
    # those out here — before fetching — instead of discovering it via a
    # boxscore 404 mid-run.
    #
    # Also checks the reverse direction: a real completed game the API knows
    # about that Selenium's schedule scrape didn't surface at all (a genuine
    # coverage gap, not a phantom). That's only logged/warned here, not
    # auto-fetched — it has no date/opponent/location metadata without the
    # schedule page, so pulling it in is a separate decision.
    try:
        authoritative_ids = {g["game_id"] for g in client.list_games(team_id, completed_only=True)}
    except Exception as exc:
        print(f"  ⚠️  Could not fetch authoritative game list for cross-check: {exc!r} — "
              f"proceeding without it (per-game 404s will still be caught individually).")
        authoritative_ids = None

    if authoritative_ids is not None:
        phantom = [g for g in games_meta if g["game_id"] not in authoritative_ids]
        if phantom:
            print(f"  ⚠️  {len(phantom)} schedule-page link(s) aren't real games in GC's API — skipping:")
            for g in phantom:
                print(f"      {g['game_id']}  {g.get('date','')}  vs {g.get('opponent','')}")
                log_failure(kind="phantom_schedule_entry", descriptor=descriptor, team_id=team_id,
                            season=season, game_id=g["game_id"], date=g.get("date", ""),
                            opponent=g.get("opponent", ""), schedule_url=schedule_url,
                            error="not in GC's authoritative completed-games list "
                                  "(TBD/rescheduled/canceled slot, most likely)")
            games_meta = [g for g in games_meta if g["game_id"] in authoritative_ids]
            if not games_meta:
                print("  ⚠️  Nothing left to fetch after removing phantom entries — skipping.")
                return None

        missing = authoritative_ids - {g["game_id"] for g in games_meta}
        if missing:
            print(f"  ⚠️  {len(missing)} completed game(s) in GC's API were NOT on the scraped "
                  f"schedule page (coverage gap, not fetched this run):")
            for gid in missing:
                print(f"      {gid}")
                log_failure(kind="missing_from_schedule_page", descriptor=descriptor, team_id=team_id,
                            season=season, game_id=gid, schedule_url=schedule_url,
                            error="in GC's completed-games list but absent from the Selenium "
                                  "schedule-page scrape")

    schedule_lookup: dict[str, dict] = {g["game_id"]: g for g in games_meta}

    raw_games: list[dict] = []
    failed_games: list[dict] = []
    game_ids = [g["game_id"] for g in games_meta]
    print(f"\nFetching {len(game_ids)} game(s)…")

    for idx, game_id in enumerate(game_ids, 1):
        meta = schedule_lookup[game_id]
        print(f"\n  [{idx}/{len(game_ids)}] {game_id}  {meta.get('date','')}  "
              f"{'@' if meta.get('home_away')=='away' else 'vs.'} {meta.get('opponent','')}")
        try:
            raw_games.append(client.get_game(game_id))
        except GCNotFound as exc:
            # A single game 404ing (deleted, admin-corrected, scorekeeper
            # error) must not take the whole team-season down with it —
            # v8/early v9 let this propagate and killed the entire batch on
            # the first bad game_id. Skip it, keep going, and record it so
            # the gap is explicit rather than silently missing from the
            # archive.
            print(f"  ⚠️  {game_id}: not found on GC — skipping this game. ({exc})")
            failed_games.append({"game_id": game_id, "date": meta.get("date", ""),
                                  "opponent": meta.get("opponent", ""), "error": str(exc)})
            log_failure(kind="game", descriptor=descriptor, team_id=team_id, season=season,
                        game_id=game_id, date=meta.get("date", ""), opponent=meta.get("opponent", ""),
                        schedule_url=schedule_url, error=str(exc))
            if idx < len(game_ids):
                jitter(*DELAY_BETWEEN_GAMES)
            continue

        if idx % 5 == 0:
            size_mb = len(json.dumps(raw_games).encode()) / (1024 ** 2)
            print(f"  📊 Data so far: {size_mb:.2f} MB")
            if size_mb > SIZE_LIMIT_MB:
                print("  ⚠️  Approaching size limit – stopping early.")
                break

        if idx < len(game_ids):
            delay = random.uniform(*DELAY_BETWEEN_GAMES)
            print(f"  … waiting {delay:.1f}s")
            time.sleep(delay)

    our_team_id = _detect_our_team_id(raw_games)
    if not our_team_id:
        print("  ⚠️  Could not detect team ID — skipping post-processing.")
        return None
    print(f"\n  Our team ID: {our_team_id}")

    roster = build_roster(raw_games, our_team_id)
    print(f"  Roster (boxscore-inferred): {len(roster)} player(s) identified")

    # ── v9: authoritative roster via the API, person_id included ───────────
    # Non-fatal — a failure here must not lose the game/boxscore/plays scrape
    # that already succeeded.
    players, handedness_cov = [], {}
    try:
        players, handedness_cov = fetch_authoritative_players(client, team_id)
        print(f"  Authoritative roster (person_id): {len(players)} player(s), "
              f"{handedness_cov.get('with_handedness', 0)} with known handedness")
    except Exception as exc:
        print(f"  ⚠️  Could not fetch authoritative players: {exc!r}")

    print(f"  Post-processing {len(raw_games)} games…")
    cleaned_games: list[dict] = []
    for game in raw_games:
        gid  = game.get("game_id", "")
        meta = schedule_lookup.get(gid, {})
        try:
            cleaned_games.append(postprocess_game(game, our_team_id, meta))
        except Exception as exc:
            print(f"    ⚠️  Could not process {gid}: {exc!r}")
            traceback.print_exc()
            game["date"]      = meta.get("date", "")
            game["home_away"] = meta.get("home_away", "")
            game["opponent"]  = meta.get("opponent", "")
            game["location"]  = meta.get("location", "")
            game["result"]    = meta.get("result", "")
            cleaned_games.append(game)

    season_stats = build_season_stats(cleaned_games, our_team_id)
    rec = season_stats["record"]
    tie_str = f"-{rec['T']}" if rec["T"] else ""
    print(f"  Season stats: {rec['W']}-{rec['L']}{tie_str}  "
          f"({len(season_stats['batting'])} batters, {len(season_stats['pitching'])} pitchers)")
    if failed_games:
        print(f"  ⚠️  {len(failed_games)} game(s) skipped (404 from GC) — see failed_games in the output JSON")

    output = {
        "metadata": {
            "descriptor":       descriptor,
            "team_name":        team_name,
            "team_id":          team_id,
            "our_team_id":      our_team_id,
            "season":           season,
            "schedule_url":     schedule_url,
            "total_games":      len(cleaned_games),
            "games_failed":     len(failed_games),
            "scrape_timestamp": datetime.now().isoformat(),
        },
        "roster":       roster,
        "season_stats": season_stats,
        "games":        cleaned_games,
        "failed_games": failed_games,
    }

    # ── D2: raw/gamechanger/{season}/{team_slug}/{scrape_date}/ ────────────
    out_dir = RAW_ROOT / season / team_slug / date.today().isoformat()
    out_dir.mkdir(parents=True, exist_ok=True)

    out_file = out_dir / f"{descriptor}.json"
    out_file.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    size_mb = out_file.stat().st_size / (1024 ** 2)
    print(f"\n  ✓ {out_file}  ({size_mb:.2f} MB, {len(cleaned_games)} games)")

    txt_file = out_dir / f"{descriptor}_stats.txt"
    txt_file.write_text(format_season_report(descriptor, season_stats), encoding="utf-8")
    print(f"  ✓ {txt_file.name}")

    if failed_games:
        # Sits right next to this team's data, plain text, one game per line —
        # readable at a glance and enough (game_id, date, opponent, schedule
        # URL) to hand straight to gc_get_game / gc_find_game later.
        failed_file = out_dir / "_failed_games.txt"
        lines = [f"{descriptor}  ({schedule_url})", f"{len(failed_games)} game(s) failed on this scrape:", ""]
        for fg in failed_games:
            lines.append(f"  game_id={fg['game_id']}  date={fg['date']}  "
                          f"opponent={fg['opponent']}\n    error: {fg['error']}")
        failed_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"  ✓ {failed_file.name}  ({len(failed_games)} failed game(s) logged)")

    if players:
        players_file = out_dir / "_players.json"
        players_file.write_text(json.dumps(players, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"  ✓ {players_file.name}  ({len(players)} players, person_id included)")

        handedness_file = out_dir / "_handedness.yaml"
        handedness_file.write_text(handedness_cov.get("yaml_fragment", ""), encoding="utf-8")
        missing = handedness_cov.get("missing_handedness", 0)
        if missing:
            print(f"  ⚠️  {missing} player(s) missing handedness from GC — see {handedness_file.name}")

        # A rescrape has just overwritten this file with GC's own values, which
        # for some teams are mostly blank. Where a coach-maintained override
        # exists, reassert it now — otherwise every rescrape silently reverts
        # real handedness to NA. No-op for teams with no override file.
        apply_overrides_to_snapshot(out_dir, team_slug)

    return output


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _resolve_batch_file() -> Path:
    """v9: an optional CLI arg names a specific batch file.

        python gc_scraper.py batch_1.txt

    Relative paths resolve against SCRIPT_DIR so `batch_1.txt` and
    `./batch_1.txt` both work regardless of the caller's cwd. Falls back to
    BATCH_FILE (batch.txt) when no argument is given.
    """
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if not args:
        return BATCH_FILE
    p = Path(args[0])
    return p if p.is_absolute() else (SCRIPT_DIR / p)


def main():
    print("=" * 70)
    print("GameChanger Scraper v9")
    print("=" * 70)

    try:
        client = build_client()
    except GCError as exc:
        sys.exit(
            f"\n❌  Could not load credentials: {exc}\n"
            "Run gc_harvest.py first (with the debug Chrome open)."
        )
    print(f"✓ {client.creds.describe()}")
    print(f"✓ raw archive root: {RAW_ROOT}")

    batch_file = _resolve_batch_file()

    print("\nMode:")
    print("  1 – Single schedule URL")
    print(f"  2 – Batch (reads {batch_file.name})")
    mode = input("\nChoice (1/2): ").strip()

    if mode == "1":
        url = input("Schedule URL: ").strip()
        if not url:
            sys.exit("❌  No URL provided.")
        schedules = [url]
    else:
        if not batch_file.exists():
            sys.exit(
                f"\n❌  Batch file not found at {batch_file}\n"
                "Create it with one schedule URL per line (lines starting "
                "with # are ignored — handy for a '# team-id' header per "
                "group), or pass a specific file: python gc_scraper.py batch_2.txt\n"
            )
        schedules = [
            line.strip()
            for line in batch_file.read_text().splitlines()
            if line.strip() and not line.startswith("#")
        ]
        if not schedules:
            sys.exit(f"❌  {batch_file.name} contains no valid URLs.")
        print(f"\n✓ Loaded {len(schedules)} schedule(s) from {batch_file.name}")

    team_failures: list[tuple[str, str]] = []
    for idx, url in enumerate(schedules, 1):
        try:
            run_schedule(url, client)
        except GCAuthError:
            # A real credential failure — every subsequent call will fail the
            # same way, so stop here rather than burning through the rest of
            # the batch on a dead token. Re-harvest and rerun this batch file.
            raise
        except Exception as exc:
            # One team's schedule failing in an unexpected way (Selenium
            # hiccup, a malformed page, etc.) must not take the rest of the
            # batch down with it — that defeats the point of splitting into
            # batches for a long, reboot-prone run. Log it, move on.
            print(f"\n  ❌  {url} failed — skipping this team and continuing.")
            print(f"      {type(exc).__name__}: {exc}")
            team_failures.append((url, f"{type(exc).__name__}: {exc}"))
            log_failure(kind="team", schedule_url=url, descriptor=descriptor_from_url(url),
                        error=f"{type(exc).__name__}: {exc}")
        if idx < len(schedules):
            delay = random.uniform(*DELAY_BETWEEN_TEAMS)
            print(f"\n  … waiting {delay:.1f}s before next team")
            time.sleep(delay)

    print(f"\n{'='*70}")
    if team_failures:
        print(f"⚠️  Done with {len(team_failures)} team(s) failed:")
        for url, err in team_failures:
            print(f"    {url}\n      {err}")
        print("Re-run just the failed URLs (mode 1, single schedule URL) once fixed.")
    else:
        print("✅  All done!")
    if FAILURE_LOG.exists():
        print(f"\nFailure log (cumulative across all runs): {FAILURE_LOG}")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
